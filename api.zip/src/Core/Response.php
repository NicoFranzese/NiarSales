<?php
declare(strict_types=1);

namespace NiarSales\Core;

final class Response
{
    /** @param array<string, mixed> $data */
    public static function json(array $data, int $statusCode = 200): never
    {
        http_response_code($statusCode);
        header('Content-Type: application/json; charset=utf-8');
        $json = json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if ($json === false) {
            http_response_code(500);
            echo '{"success":false,"message":"No se pudo generar la respuesta JSON."}';
            exit;
        }
        echo $json;
        exit;
    }
}
