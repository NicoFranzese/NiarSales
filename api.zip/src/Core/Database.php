<?php
declare(strict_types=1);

namespace NiarSales\Core;

use PDO;
use RuntimeException;

final class Database
{
    private static ?PDO $connection = null;

    /** @param array<string, mixed> $config */
    public static function connection(array $config): PDO
    {
        if (self::$connection instanceof PDO) {
            return self::$connection;
        }

        foreach (['host', 'database', 'username', 'password'] as $key) {
            if (!isset($config[$key]) || $config[$key] === '' ||
                str_starts_with((string) $config[$key], 'REEMPLAZAR_')) {
                throw new RuntimeException('La configuración de MySQL está incompleta.');
            }
        }

        $dsn = sprintf(
            'mysql:host=%s;port=%d;dbname=%s;charset=%s',
            (string) $config['host'],
            (int) ($config['port'] ?? 3306),
            (string) $config['database'],
            (string) ($config['charset'] ?? 'utf8mb4')
        );

        self::$connection = new PDO(
            $dsn,
            (string) $config['username'],
            (string) $config['password'],
            [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
                PDO::ATTR_TIMEOUT => 5,
            ]
        );

        return self::$connection;
    }
}
