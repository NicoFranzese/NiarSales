<?php
declare(strict_types=1);

namespace NiarSales\Core;

use PDO;
use RuntimeException;
use DateTimeImmutable;
use DateTimeZone;

final class BudgetExceededException extends RuntimeException {}

/** Control mensual de gasto exclusivo de las llamadas realizadas por NiarSales. */
final class BudgetService
{
    private const INPUT_USD_PER_MILLION = 0.40;
    private const OUTPUT_USD_PER_MILLION = 1.60;
    private PDO $pdo;

    public function __construct(PDO $pdo) { $this->pdo = $pdo; }

    private function month(): string
    {
        return (new DateTimeImmutable('now', new DateTimeZone('UTC')))->format('Y-m');
    }

    private function ensureReady(): void
    {
        // Las tablas se crean mediante la migración SQL incluida en el paquete.
        foreach (['niarsales_ai_budget', 'niarsales_ai_usage'] as $table) {
            // Consultamos information_schema en lugar de parametrizar SHOW TABLES,
            // ya que MySQL/PDO puede rechazar parámetros en sentencias SHOW.
            $q = $this->pdo->prepare(
                'SELECT COUNT(*) FROM information_schema.tables
                 WHERE table_schema = DATABASE() AND table_name = :name'
            );
            $q->execute(['name' => $table]);
            if (!(int) $q->fetchColumn()) {
                throw new RuntimeException('Falta ejecutar la migración de presupuesto de IA: ' . $table);
            }
        }
    }

    public function status(): array
    {
        $this->ensureReady();
        $q = $this->pdo->query('SELECT monthly_limit_usd, enabled FROM niarsales_ai_budget WHERE id = 1');
        $cfg = $q->fetch(PDO::FETCH_ASSOC);
        if (!$cfg) throw new RuntimeException('No existe la configuración inicial del presupuesto de IA.');
        $month = $this->month();
        $q = $this->pdo->prepare('SELECT
            COALESCE(SUM(cost_usd),0) AS spent,
            COALESCE(SUM(reserved_usd),0) AS reserved,
            COALESCE(SUM(input_tokens),0) AS input_tokens,
            COALESCE(SUM(output_tokens),0) AS output_tokens,
            COUNT(*) AS requests,
            SUM(CASE WHEN status = \'completed\' THEN 1 ELSE 0 END) AS completed_requests,
            SUM(CASE WHEN status = \'failed\' THEN 1 ELSE 0 END) AS failed_requests
            FROM niarsales_ai_usage WHERE billing_month = :month');
        $q->execute(['month' => $month]);
        $totals = $q->fetch(PDO::FETCH_ASSOC) ?: ['spent'=>0,'reserved'=>0,'input_tokens'=>0,'output_tokens'=>0,'requests'=>0,'completed_requests'=>0,'failed_requests'=>0];
        $limit = (float)$cfg['monthly_limit_usd'];
        $spent = (float)$totals['spent'];
        $reserved = (float)$totals['reserved'];
        return [
            'month' => $month,
            'monthly_limit_usd' => $limit,
            'spent_usd' => round($spent, 6),
            'reserved_usd' => round($reserved, 6),
            'available_usd' => round(max(0, $limit - $spent - $reserved), 6),
            'input_tokens' => (int)$totals['input_tokens'],
            'output_tokens' => (int)$totals['output_tokens'],
            'total_tokens' => (int)$totals['input_tokens'] + (int)$totals['output_tokens'],
            'requests' => (int)$totals['requests'],
            'completed_requests' => (int)$totals['completed_requests'],
            'failed_requests' => (int)$totals['failed_requests'],
            'enabled' => (bool)$cfg['enabled'],
            'currency' => 'USD'
        ];
    }

    private function priceFor(string $model): array
    {
        // Precio oficial Standard vigente consultado el 15/11/2026.
        // No se permite ejecutar modelos sin tarifa conocida: evita subestimar el gasto.
        if ($model === 'gpt-4.1-mini' || $model === 'gpt-4.1-mini-2025-04-14') {
            return [self::INPUT_USD_PER_MILLION, self::OUTPUT_USD_PER_MILLION];
        }
        throw new RuntimeException('No hay una tarifa configurada para el modelo OpenAI "'.$model.'". La ejecución se bloqueó para evitar calcular mal el gasto.');
    }

    public function reserve(string $model, int $estimatedInputTokens, int $maxOutputTokens): int
    {
        $this->ensureReady();
        [$inputRate, $outputRate] = $this->priceFor($model);
        $estimated = ($estimatedInputTokens * $inputRate + $maxOutputTokens * $outputRate) / 1000000;
        $this->pdo->beginTransaction();
        try {
            // El bloqueo de la fila única evita que dos ejecuciones simultáneas superen el saldo disponible.
            $cfg = $this->pdo->query('SELECT monthly_limit_usd, enabled FROM niarsales_ai_budget WHERE id = 1 FOR UPDATE')->fetch(PDO::FETCH_ASSOC);
            if (!$cfg) throw new RuntimeException('No existe la configuración inicial del presupuesto de IA.');
            if (!(bool)$cfg['enabled']) throw new BudgetExceededException('El uso de OpenAI está deshabilitado desde el presupuesto de NiarSales.');
            $month = $this->month();
            $q = $this->pdo->prepare('SELECT COALESCE(SUM(cost_usd + reserved_usd),0) FROM niarsales_ai_usage WHERE billing_month = :month');
            $q->execute(['month' => $month]);
            $committed = (float)$q->fetchColumn();
            $limit = (float)$cfg['monthly_limit_usd'];
            if ($committed + $estimated > $limit + 0.0000001) {
                throw new BudgetExceededException(sprintf('Se alcanzaría el presupuesto mensual de NiarSales. Gastado/reservado: US$ %.4f de US$ %.2f. No se realizó la consulta a OpenAI.', $committed, $limit));
            }
            $insert = $this->pdo->prepare('INSERT INTO niarsales_ai_usage (billing_month, model, input_tokens, output_tokens, estimated_input_tokens, reserved_usd, cost_usd, status, created_at) VALUES (:month,:model,0,0,:estimated_tokens,:reserved,0,\'reserved\',NOW())');
            $insert->execute(['month'=>$month,'model'=>$model,'estimated_tokens'=>$estimatedInputTokens,'reserved'=>$estimated]);
            $id = (int)$this->pdo->lastInsertId();
            $this->pdo->commit();
            return $id;
        } catch (\Throwable $e) {
            if ($this->pdo->inTransaction()) $this->pdo->rollBack();
            throw $e;
        }
    }

    public function settle(int $usageId, string $model, int $inputTokens, int $outputTokens): float
    {
        [$inputRate, $outputRate] = $this->priceFor($model);
        $cost = ($inputTokens * $inputRate + $outputTokens * $outputRate) / 1000000;
        $q = $this->pdo->prepare('UPDATE niarsales_ai_usage SET input_tokens=:input, output_tokens=:output, reserved_usd=0, cost_usd=:cost, status=\'completed\', completed_at=NOW() WHERE id=:id AND status=\'reserved\'');
        $q->execute(['input'=>$inputTokens,'output'=>$outputTokens,'cost'=>$cost,'id'=>$usageId]);
        return $cost;
    }

    public function release(int $usageId, string $error): void
    {
        $q = $this->pdo->prepare('UPDATE niarsales_ai_usage SET reserved_usd=0, status=\'failed\', error_message=:error, completed_at=NOW() WHERE id=:id AND status=\'reserved\'');
        $q->execute(['error'=>mb_substr($error,0,1000),'id'=>$usageId]);
    }

    public function updateLimit(float $limit, bool $enabled): void
    {
        if ($limit < 0.01 || $limit > 10000) throw new RuntimeException('El presupuesto debe estar entre US$ 0,01 y US$ 10.000.');
        $q = $this->pdo->prepare('UPDATE niarsales_ai_budget SET monthly_limit_usd=:limit, enabled=:enabled, updated_at=NOW() WHERE id=1');
        $q->execute(['limit'=>number_format($limit,2,'.',''),'enabled'=>$enabled ? 1 : 0]);
        if ($q->rowCount() === 0) {
            $check=$this->pdo->query('SELECT COUNT(*) FROM niarsales_ai_budget WHERE id=1')->fetchColumn();
            if (!(int)$check) throw new RuntimeException('No existe la fila inicial del presupuesto. Ejecutá nuevamente la migración.');
        }
    }
}
