<?php
declare(strict_types=1);

namespace NiarSales\Core;

final class AuthGuard
{
    public static function requireUser(): int
    {
        if (empty($_SESSION['user']['id'])) {
            Response::json(['success' => false, 'message' => 'La sesión expiró. Iniciá sesión nuevamente.'], 401);
        }
        return (int) $_SESSION['user']['id'];
    }

    public static function requireCsrf(): void
    {
        $provided = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
        $expected = $_SESSION['csrf_token'] ?? '';
        if (!is_string($provided) || !is_string($expected) || $provided === '' || $expected === '' || !hash_equals($expected, $provided)) {
            Response::json(['success' => false, 'message' => 'Token de seguridad inválido. Actualizá la sesión.'], 419);
        }
    }
}
