<?php
declare(strict_types=1);

namespace NiarSales\Controllers;

use NiarSales\Core\Database;
use NiarSales\Core\Response;
use PDO;
use Throwable;

final class ActivityController
{
    private PDO $pdo;

    public function __construct(array $dbConfig)
    {
        $this->pdo = Database::connection($dbConfig);
    }

    private function userId(): int
    {
        if (empty($_SESSION['user']['id'])) {
            Response::json(['success' => false, 'message' => 'La sesión expiró. Iniciá sesión nuevamente.'], 401);
        }
        return (int) $_SESSION['user']['id'];
    }

    private function csrf(): void
    {
        $provided = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
        $expected = $_SESSION['csrf_token'] ?? '';
        if (!is_string($provided) || !is_string($expected) || $provided === '' || $expected === '' || !hash_equals($expected, $provided)) {
            Response::json(['success' => false, 'message' => 'Token de seguridad inválido. Actualizá la sesión.'], 419);
        }
    }

    private function input(): array
    {
        $data = json_decode(file_get_contents('php://input') ?: '{}', true);
        return is_array($data) ? $data : [];
    }

    private function ensureProspect(int $id): void
    {
        $stmt = $this->pdo->prepare('SELECT id FROM prospectos WHERE id = :id LIMIT 1');
        $stmt->execute(['id' => $id]);
        if (!$stmt->fetchColumn()) {
            Response::json(['success' => false, 'message' => 'No se encontró el prospecto.'], 404);
        }
    }

    public function list(int $prospectId): never
    {
        $this->userId();
        try {
            $this->ensureProspect($prospectId);
            $stmt = $this->pdo->prepare(
                'SELECT id, prospecto_id, usuario_id, tipo, canal, resultado, detalle, mensaje,
                        proximo_contacto, created_at
                 FROM prospecto_actividades
                 WHERE prospecto_id = :prospecto_id
                 ORDER BY created_at DESC, id DESC'
            );
            $stmt->execute(['prospecto_id' => $prospectId]);
            Response::json(['success' => true, 'data' => $stmt->fetchAll(PDO::FETCH_ASSOC)]);
        } catch (Throwable $e) {
            error_log('[NiarSales activities list] ' . $e->getMessage());
            Response::json(['success' => false, 'message' => 'No se pudo cargar el historial. Verificá la migración de seguimiento.'], 500);
        }
    }

    public function create(int $prospectId): never
    {
        $userId = $this->userId();
        $this->csrf();
        try {
            $this->ensureProspect($prospectId);
            $data = $this->input();
            $allowedTypes = ['contacto', 'respuesta', 'nota', 'seguimiento', 'demostracion', 'cambio_estado'];
            $allowedChannels = ['whatsapp', 'telefono', 'instagram', 'facebook', 'email', 'presencial', 'interno'];
            $tipo = trim((string)($data['tipo'] ?? ''));
            $canal = trim((string)($data['canal'] ?? 'interno'));
            if (!in_array($tipo, $allowedTypes, true)) {
                Response::json(['success' => false, 'message' => 'Tipo de actividad inválido.'], 422);
            }
            if (!in_array($canal, $allowedChannels, true)) {
                Response::json(['success' => false, 'message' => 'Canal inválido.'], 422);
            }
            $detalle = trim((string)($data['detalle'] ?? ''));
            $mensaje = trim((string)($data['mensaje'] ?? ''));
            if ($detalle === '' && $mensaje === '') {
                Response::json(['success' => false, 'message' => 'Ingresá un detalle o mensaje para registrar la actividad.'], 422);
            }
            $next = trim((string)($data['proximo_contacto'] ?? ''));
            $nextValue = $next !== '' ? str_replace('T', ' ', $next) : null;
            if ($nextValue !== null && strlen($nextValue) === 16) $nextValue .= ':00';

            $stmt = $this->pdo->prepare(
                'INSERT INTO prospecto_actividades
                 (prospecto_id, usuario_id, tipo, canal, resultado, detalle, mensaje, proximo_contacto, created_at)
                 VALUES (:prospecto_id, :usuario_id, :tipo, :canal, :resultado, :detalle, :mensaje, :proximo_contacto, NOW())'
            );
            $stmt->execute([
                'prospecto_id' => $prospectId,
                'usuario_id' => $userId,
                'tipo' => $tipo,
                'canal' => $canal,
                'resultado' => trim((string)($data['resultado'] ?? '')),
                'detalle' => $detalle,
                'mensaje' => $mensaje,
                'proximo_contacto' => $nextValue,
            ]);
            Response::json(['success' => true, 'message' => 'Actividad registrada.', 'id' => (int)$this->pdo->lastInsertId()], 201);
        } catch (Throwable $e) {
            error_log('[NiarSales activities create] ' . $e->getMessage());
            Response::json(['success' => false, 'message' => 'No se pudo registrar la actividad. Verificá la migración de seguimiento.'], 500);
        }
    }
}
