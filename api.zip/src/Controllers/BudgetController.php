<?php
declare(strict_types=1);

namespace NiarSales\Controllers;

use NiarSales\Core\AuthGuard;
use NiarSales\Core\BudgetService;
use NiarSales\Core\Database;
use NiarSales\Core\Response;
use PDO;
use Throwable;

final class BudgetController
{
    private PDO $pdo;
    private BudgetService $budget;
    public function __construct(array $dbConfig)
    {
        $this->pdo = Database::connection($dbConfig);
        $this->budget = new BudgetService($this->pdo);
    }
    public function status(): never
    {
        AuthGuard::requireUser();
        try { Response::json(['success'=>true,'data'=>$this->budget->status()]); }
        catch (Throwable $e) { error_log('[NiarSales budget status] '.$e->getMessage()); Response::json(['success'=>false,'message'=>'No se pudo consultar el presupuesto. Verificá que la migración esté instalada.'],500); }
    }
    public function update(): never
    {
        AuthGuard::requireUser(); AuthGuard::requireCsrf();
        if (($_SESSION['user']['rol'] ?? '') !== 'administrador') Response::json(['success'=>false,'message'=>'Solo un administrador puede modificar el presupuesto.'],403);
        $data=json_decode((string)file_get_contents('php://input'),true);
        if (!is_array($data) || !isset($data['monthly_limit_usd'])) Response::json(['success'=>false,'message'=>'Indicá el presupuesto mensual en dólares.'],422);
        try {
            $this->budget->updateLimit((float)$data['monthly_limit_usd'], (bool)($data['enabled'] ?? true));
            Response::json(['success'=>true,'message'=>'Presupuesto actualizado.','data'=>$this->budget->status()]);
        } catch (Throwable $e) { Response::json(['success'=>false,'message'=>$e->getMessage()],422); }
    }
}
