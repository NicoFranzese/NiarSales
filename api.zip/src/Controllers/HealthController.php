<?php
declare(strict_types=1);

namespace NiarSales\Controllers;

use NiarSales\Core\Database;
use NiarSales\Core\Response;
use Throwable;

final class HealthController
{
    /** @param array<string, mixed> $dbConfig */
    public function index(array $dbConfig): never
    {
        try {
            Database::connection($dbConfig)->query('SELECT 1');
        } catch (Throwable $exception) {
            error_log('[NiarSales DB health check] ' . $exception->getMessage());
            Response::json([
                'success' => false,
                'application' => 'NiarSales',
                'api' => 'ok',
                'database' => 'disconnected',
                'message' => 'La API responde, pero no pudo conectarse a la base de datos.'
            ], 503);
        }

        Response::json([
            'success' => true,
            'application' => 'NiarSales',
            'api' => 'ok',
            'database' => 'connected',
            'timestamp' => date(DATE_ATOM)
        ]);
    }
}
