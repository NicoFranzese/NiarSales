<?php
declare(strict_types=1);

namespace NiarSales\Controllers;

use NiarSales\Core\Database;
use NiarSales\Core\Response;
use PDO;
use Throwable;

/** Read-only status API for the NiarSales Virtual Office. */
final class OfficeController
{
    private PDO $pdo;

    public function __construct(array $dbConfig)
    {
        $this->pdo = Database::connection($dbConfig);
    }

    public function snapshot(): never
    {
        if (empty($_SESSION['user']['id'])) {
            Response::json(['success' => false, 'message' => 'La sesión expiró. Iniciá sesión nuevamente.'], 401);
        }

        try {
            $agents = $this->pdo->query(
                "SELECT slug, nombre, rol, sala, descripcion, habilitado, avatar, orden
                 FROM agentes_niarsales WHERE habilitado = 1 ORDER BY orden ASC, id ASC"
            )->fetchAll(PDO::FETCH_ASSOC);

            $executions = $this->pdo->query(
                "SELECT id, tipo, estado, objetivo, parametros_json, resultado_resumen, error_detalle,
                        cantidad_prospectos, fecha_inicio, fecha_fin, created_at
                 FROM ejecuciones_agente ORDER BY id DESC LIMIT 12"
            )->fetchAll(PDO::FETCH_ASSOC);

            $events = $this->pdo->query(
                "SELECT e.id, e.agente_slug, a.nombre AS agente_nombre, e.ejecucion_id,
                        e.tipo, e.estado, e.mensaje, e.detalle_json, e.created_at
                 FROM eventos_agente e
                 LEFT JOIN agentes_niarsales a ON a.slug = e.agente_slug
                 ORDER BY e.id DESC LIMIT 30"
            )->fetchAll(PDO::FETCH_ASSOC);

            foreach ($events as &$event) {
                $event['detalle'] = $event['detalle_json'] ? json_decode((string)$event['detalle_json'], true) : null;
                unset($event['detalle_json']);
            }
            unset($event);

            foreach ($executions as &$execution) {
                $execution['parametros'] = $execution['parametros_json'] ? json_decode((string)$execution['parametros_json'], true) : [];
                unset($execution['parametros_json']);
            }
            unset($execution);

            $active = null;
            foreach ($executions as $execution) {
                if (in_array($execution['estado'], ['ejecutando', 'pendiente'], true)) {
                    $active = $execution;
                    break;
                }
            }

            Response::json([
                'success' => true,
                'data' => [
                    'agents' => $agents,
                    'executions' => $executions,
                    'events' => $events,
                    'active_execution' => $active,
                    'server_time' => date('Y-m-d H:i:s'),
                ],
            ]);
        } catch (Throwable $e) {
            error_log('[NiarSales virtual office] ' . $e->getMessage());
            Response::json(['success' => false, 'message' => 'No se pudo consultar el estado de la oficina virtual. Ejecutá la migración de Virtual Office y volvé a intentar.'], 500);
        }
    }
}
