<?php
declare(strict_types=1);

namespace NiarSales\Controllers;

use NiarSales\Core\Database;
use NiarSales\Core\BudgetService;
use NiarSales\Core\BudgetExceededException;
use NiarSales\Core\Response;
use PDO;
use RuntimeException;
use Throwable;

final class AdaController
{
    private PDO $pdo;
    private array $cfg;
    private BudgetService $budget;

    public function __construct(array $dbConfig, array $agentConfig)
    {
        $this->pdo = Database::connection($dbConfig);
        $this->cfg = $agentConfig;
        $this->budget = new BudgetService($this->pdo);
    }

    private function authorize(): int
    {
        if (empty($_SESSION['user']['id'])) Response::json(['success'=>false,'message'=>'La sesión expiró. Iniciá sesión nuevamente.'], 401);
        $got = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
        $expected = $_SESSION['csrf_token'] ?? '';
        if (!is_string($got) || !is_string($expected) || $got === '' || $expected === '' || !hash_equals($expected, $got)) {
            Response::json(['success'=>false,'message'=>'Token de seguridad inválido. Actualizá la sesión.'], 419);
        }
        return (int)$_SESSION['user']['id'];
    }

    private function authorizeRead(): void
    {
        if (empty($_SESSION['user']['id'])) Response::json(['success'=>false,'message'=>'La sesión expiró. Iniciá sesión nuevamente.'], 401);
    }

    private function event(int $executionId, string $type, string $state, string $message, array $detail=[]): void
    {
        try {
            $q=$this->pdo->prepare('INSERT INTO eventos_agente (agente_slug, ejecucion_id, tipo, estado, mensaje, detalle_json, created_at) VALUES (\'analista\',:execution,:type,:state,:message,:detail,NOW())');
            $q->execute(['execution'=>$executionId,'type'=>$type,'state'=>$state,'message'=>$message,'detail'=>json_encode($detail,JSON_UNESCAPED_UNICODE)]);
        } catch (Throwable $e) { error_log('[NiarSales Ada event] '.$e->getMessage()); }
    }

    private function callAda(array $prospect): array
    {
        $key=(string)($this->cfg['openai_api_key']??'');
        if ($key==='' || str_starts_with($key,'PEGAR_')) throw new RuntimeException('Falta configurar OpenAI API en api/config/agent.php.');
        if (!function_exists('curl_init')) throw new RuntimeException('La extensión cURL de PHP no está habilitada.');
        $system='Sos Ada, analista comercial B2B de NiarSales. Evaluás prospectos para ofrecer MesAPP, una solución de menú digital y gestión de pedidos. Usá EXCLUSIVAMENTE los datos entregados. No navegaste internet ni verificaste redes; no inventes datos ni supongas ausencia de servicios. Separá hechos de hipótesis. Si faltan datos, bajá la confianza y decilo. Respondé únicamente JSON válido con: puntuacion (entero 0-100), prioridad (alta|media|baja), resumen (máximo 450 caracteres), fortalezas (array de 1 a 4), riesgos (array de 1 a 4), datos_faltantes (array), recomendacion (máximo 500 caracteres), confianza (alta|media|baja). La puntuación mide atractivo comercial preliminar para MesAPP, no probabilidad estadística de compra. Considerá alineación del rubro, reputación y volumen de reseñas cuando estén disponibles, canales de contacto y evidencia digital realmente disponible.';
        $user='Producto: '.($this->cfg['product_name']??'MesAPP').'. '.($this->cfg['product_description']??'')."\nFicha del prospecto y evaluación previa de Ivo (puede contener datos incompletos):\n".json_encode($prospect,JSON_UNESCAPED_UNICODE);
        $model=(string)($this->cfg['openai_model']??'gpt-4.1-mini');
        $maxOutput=450;
        $payload=['model'=>$model,'messages'=>[['role'=>'system','content'=>$system],['role'=>'user','content'=>$user]],'response_format'=>['type'=>'json_object'],'temperature'=>0.15,'max_tokens'=>$maxOutput];
        $estimated=(int)ceil((strlen($system)+strlen($user))/3*1.25);
        $usageId=$this->budget->reserve($model,$estimated,$maxOutput);
        try {
            $ch=curl_init('https://api.openai.com/v1/chat/completions');
            curl_setopt_array($ch,[CURLOPT_POST=>true,CURLOPT_RETURNTRANSFER=>true,CURLOPT_POSTFIELDS=>json_encode($payload),CURLOPT_HTTPHEADER=>['Content-Type: application/json','Authorization: Bearer '.$key],CURLOPT_TIMEOUT=>40]);
            $body=curl_exec($ch);$status=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);$err=curl_error($ch);curl_close($ch);
            if($body===false) throw new RuntimeException('No se pudo consultar OpenAI: '.$err);
            $json=json_decode((string)$body,true);
            if($status<200||$status>=300) throw new RuntimeException('OpenAI rechazó el análisis: '.($json['error']['message']??('HTTP '.$status)));
            $analysis=json_decode((string)($json['choices'][0]['message']['content']??''),true);
            if(!is_array($analysis)) throw new RuntimeException('Ada recibió una respuesta que no pudo interpretar.');
            $in=(int)($json['usage']['prompt_tokens']??0);$out=(int)($json['usage']['completion_tokens']??0);
            $cost=$this->budget->settle($usageId,(string)($json['model']??$model),$in,$out);
            $analysis['_usage']=['input_tokens'=>$in,'output_tokens'=>$out,'model'=>$json['model']??$model,'cost_usd'=>$cost];
            return $analysis;
        } catch(Throwable $e) { $this->budget->release($usageId,$e->getMessage()); throw $e; }
    }

    public function candidates(): never
    {
        $this->authorizeRead();
        $search = trim((string)($_GET['q'] ?? ''));
        $view = (string)($_GET['view'] ?? 'pending');
        if (!in_array($view, ['pending', 'analyzed'], true)) $view = 'pending';

        try {
            // Conteos globales: permiten saber si realmente hay trabajo pendiente
            // aunque el filtro de búsqueda actual no devuelva resultados.
            $counts = $this->pdo->query(
                "SELECT COUNT(*) AS total,
                        SUM(CASE WHEN ada_analizado_at IS NULL THEN 1 ELSE 0 END) AS pending,
                        SUM(CASE WHEN ada_analizado_at IS NOT NULL THEN 1 ELSE 0 END) AS analyzed
                 FROM prospectos"
            )->fetch(PDO::FETCH_ASSOC) ?: [];

            $sql = "SELECT p.id,p.nombre_comercial,p.razon_social,p.localidad,p.provincia,p.telefono,p.sitio_web,
                           p.estado,p.prioridad,p.puntuacion,p.ada_puntuacion,p.ada_prioridad,
                           p.ada_resumen,p.ada_analizado_at,r.nombre AS rubro,
                           ra.datos_json AS investigacion_ivo
                    FROM prospectos p
                    LEFT JOIN rubros r ON r.id=p.rubro_id
                    LEFT JOIN (
                      SELECT x.prospecto_id,x.datos_json
                      FROM resultados_agente x
                      INNER JOIN (
                        SELECT prospecto_id,MAX(id) AS max_id
                        FROM resultados_agente
                        WHERE prospecto_id IS NOT NULL AND tipo='prospecto_encontrado'
                        GROUP BY prospecto_id
                      ) latest ON latest.max_id=x.id
                    ) ra ON ra.prospecto_id=p.id
                    WHERE ";
            $sql .= $view === 'pending' ? "p.ada_analizado_at IS NULL" : "p.ada_analizado_at IS NOT NULL";

            $params = [];
            if ($search !== '') {
                $sql .= " AND (p.nombre_comercial LIKE :q_nombre
                           OR p.razon_social LIKE :q_razon
                           OR p.localidad LIKE :q_localidad
                           OR r.nombre LIKE :q_rubro)";
                $term = '%' . $search . '%';
                $params = [
                    'q_nombre' => $term,
                    'q_razon' => $term,
                    'q_localidad' => $term,
                    'q_rubro' => $term
                ];
            }
            $sql .= $view === 'pending'
                ? " ORDER BY p.id DESC LIMIT 150"
                : " ORDER BY p.ada_analizado_at DESC,p.id DESC LIMIT 150";

            $stmt = $this->pdo->prepare($sql);
            $stmt->execute($params);
            $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

            foreach ($rows as &$row) {
                $row['id'] = (int)$row['id'];
                $row['puntuacion'] = $row['puntuacion'] !== null ? (int)$row['puntuacion'] : null;
                $row['ada_puntuacion'] = $row['ada_puntuacion'] !== null ? (int)$row['ada_puntuacion'] : null;
                $raw = json_decode((string)($row['investigacion_ivo'] ?? ''), true);
                $row['investigacion_ivo'] = is_array($raw) ? ($raw['analysis'] ?? $raw) : null;
                $row['ada_estado'] = $row['ada_analizado_at'] !== null ? 'analizado' : 'pendiente';
            }
            unset($row);

            Response::json([
                'success' => true,
                'data' => [
                    'candidates' => $rows,
                    'count' => count($rows),
                    'counts' => [
                        'total' => (int)($counts['total'] ?? 0),
                        'pending' => (int)($counts['pending'] ?? 0),
                        'analyzed' => (int)($counts['analyzed'] ?? 0)
                    ],
                    'view' => $view
                ]
            ]);
        } catch (Throwable $e) {
            error_log('[NiarSales Ada candidates] '.$e->getMessage().' | view='.$view.' | search='.$search);
            Response::json([
                'success'=>false,
                'message'=>'No se pudieron consultar los prospectos de Ada. Verificá que esté aplicada la migración de evaluación de Ada.',
                'code'=>'ADA_CANDIDATES_QUERY_ERROR'
            ],500);
        }
    }

    public function run(): never
    {
        $userId=$this->authorize();
        $input=json_decode((string)file_get_contents('php://input'),true) ?: [];
        $requestedIds=$input['prospecto_ids']??[];
        if(!is_array($requestedIds)) Response::json(['success'=>false,'message'=>'La selección de prospectos no es válida.'],422);
        $requestedIds=array_values(array_unique(array_filter(array_map('intval',$requestedIds),static fn($id)=>$id>0)));
        if(count($requestedIds)>5) Response::json(['success'=>false,'message'=>'Ada puede analizar hasta 5 prospectos por tarea.'],422);
        $limit=count($requestedIds)>0?count($requestedIds):max(1,min(5,(int)($input['cantidad']??3)));
        $active=$this->pdo->query("SELECT id FROM ejecuciones_agente WHERE estado='ejecutando' ORDER BY id DESC LIMIT 1")->fetchColumn();
        if($active) Response::json(['success'=>false,'message'=>'Hay otra tarea en curso (ejecución #'.(int)$active.'). Esperá a que termine.'],409);

        $baseSelect='SELECT p.id,p.nombre_comercial,p.razon_social,p.rubro_id,r.nombre AS rubro,p.sitio_web,p.instagram_url,p.facebook_url,p.telefono,p.telefono_tipo,p.email,p.direccion,p.localidad,p.provincia,p.pais,p.estado,p.prioridad,p.puntuacion,p.mensaje_sugerido_ia,p.created_at,ra.datos_json AS investigacion_ivo FROM prospectos p LEFT JOIN rubros r ON r.id=p.rubro_id LEFT JOIN (SELECT x.prospecto_id,x.datos_json FROM resultados_agente x INNER JOIN (SELECT prospecto_id,MAX(id) max_id FROM resultados_agente WHERE prospecto_id IS NOT NULL AND tipo IN (\'prospecto_encontrado\',\'prospecto_investigado\') GROUP BY prospecto_id) z ON z.max_id=x.id) ra ON ra.prospecto_id=p.id';
        if($requestedIds){
            $placeholders=implode(',',array_fill(0,count($requestedIds),'?'));
            $stmt=$this->pdo->prepare($baseSelect.' WHERE p.ada_analizado_at IS NULL AND p.id IN ('.$placeholders.') ORDER BY FIELD(p.id,'.$placeholders.')');
            $stmt->execute(array_merge($requestedIds,$requestedIds));
            $prospects=$stmt->fetchAll(PDO::FETCH_ASSOC);
            if(count($prospects)!==count($requestedIds)) Response::json(['success'=>false,'message'=>'Uno o más prospectos seleccionados ya fueron analizados o no existen. Actualizá la lista y volvé a seleccionar.'],409);
        } else {
            $stmt=$this->pdo->prepare($baseSelect.' WHERE p.ada_analizado_at IS NULL ORDER BY p.id DESC LIMIT :lim');
            $stmt->bindValue(':lim',$limit,PDO::PARAM_INT);$stmt->execute();$prospects=$stmt->fetchAll(PDO::FETCH_ASSOC);
        }
        if(!$prospects) Response::json(['success'=>true,'message'=>'No hay prospectos pendientes de análisis para Ada.','analyzed'=>0,'skipped'=>0]);

        $selectedNames=array_map(static fn($p)=>(string)$p['nombre_comercial'],$prospects);
        $objective='Ada: analizar '.count($prospects).' prospectos: '.implode(', ',array_slice($selectedNames,0,4));
        $q=$this->pdo->prepare("INSERT INTO ejecuciones_agente (tipo,estado,iniciado_por,objetivo,parametros_json,cantidad_prospectos,fecha_inicio,created_at) VALUES ('calificacion','ejecutando',:user,:objective,:params,0,NOW(),NOW())");
        $q->execute(['user'=>$userId,'objective'=>$objective,'params'=>json_encode(['agente'=>'analista','cantidad'=>count($prospects),'prospecto_ids'=>array_map(static fn($p)=>(int)$p['id'],$prospects)],JSON_UNESCAPED_UNICODE)]);
        $executionId=(int)$this->pdo->lastInsertId();
        $this->event($executionId,'analisis_iniciado','working','Ada comenzó a analizar los prospectos seleccionados.',['cantidad'=>count($prospects),'prospectos'=>$selectedNames]);
        $done=0;$errors=[];
        try {
            foreach($prospects as $p) {
                try {
                    $prior=json_decode((string)($p['investigacion_ivo']??''),true);
                    $context=['prospecto'=>[
                        'id'=>(int)$p['id'],'nombre'=>$p['nombre_comercial'],'razon_social'=>$p['razon_social'],'rubro'=>$p['rubro'],
                        'sitio_web'=>$p['sitio_web'],'instagram'=>$p['instagram_url'],'facebook'=>$p['facebook_url'],
                        'telefono'=>$p['telefono'],'telefono_tipo'=>$p['telefono_tipo'],'email'=>$p['email'],
                        'direccion'=>$p['direccion'],'localidad'=>$p['localidad'],'provincia'=>$p['provincia'],'pais'=>$p['pais'],
                        'estado'=>$p['estado'],'prioridad_ivo'=>$p['prioridad'],'puntuacion_ivo'=>$p['puntuacion'],
                        'mensaje_sugerido_ivo'=>$p['mensaje_sugerido_ia'],'fecha_alta'=>$p['created_at']
                    ],'investigacion_previa_ivo'=>$prior];
                    $a=$this->callAda($context);
                    $score=max(0,min(100,(int)($a['puntuacion']??0)));
                    $priority=in_array(($a['prioridad']??''),['alta','media','baja'],true)?$a['prioridad']:'media';
                    $summary=mb_substr(trim((string)($a['resumen']??'')),0,450,'UTF-8');
                    $recommendation=mb_substr(trim((string)($a['recomendacion']??'')),0,500,'UTF-8');
                    $upd=$this->pdo->prepare('UPDATE prospectos SET ada_puntuacion=:score,ada_prioridad=:priority,ada_resumen=:summary,ada_recomendacion=:recommendation,ada_analisis_json=:json,ada_analizado_at=NOW() WHERE id=:id AND ada_analizado_at IS NULL');
                    $upd->execute(['score'=>$score,'priority'=>$priority,'summary'=>$summary,'recommendation'=>$recommendation,'json'=>json_encode($a,JSON_UNESCAPED_UNICODE),'id'=>(int)$p['id']]);
                    $log=$this->pdo->prepare("INSERT INTO resultados_agente (ejecucion_id,prospecto_id,tipo,titulo,contenido,datos_json,created_at) VALUES (:execution,:prospect,'analisis',:title,:content,:data,NOW())");
                    $log->execute(['execution'=>$executionId,'prospect'=>(int)$p['id'],'title'=>'Ada · '.$p['nombre_comercial'],'content'=>$summary,'data'=>json_encode(['analisis_ada'=>$a,'contexto_analizado'=>$context],JSON_UNESCAPED_UNICODE)]);
                    $done++;
                    $this->event($executionId,'prospecto_calificado','working','Ada evaluó '.$p['nombre_comercial'].'.',['prospecto_id'=>(int)$p['id'],'puntuacion'=>$score,'prioridad'=>$priority]);
                } catch(BudgetExceededException $e) { $errors[]=$e->getMessage(); break; }
                  catch(Throwable $e) { $errors[]=$p['nombre_comercial'].': '.$e->getMessage(); error_log('[NiarSales Ada item] '.$e->getMessage()); }
            }
            $summary=$done.' prospectos analizados por Ada'.($errors?'; '.count($errors).' incidencias.':'.');
            $end=$this->pdo->prepare("UPDATE ejecuciones_agente SET estado=:state,resultado_resumen=:summary,error_detalle=:error,cantidad_prospectos=:count,fecha_fin=NOW() WHERE id=:id");
            $end->execute(['state'=>$done>0?'completada':'fallida','summary'=>$summary,'error'=>$errors?implode(' | ',array_slice($errors,0,5)):null,'count'=>$done,'id'=>$executionId]);
            $this->event($executionId,'analisis_completado','success',$summary,['analizados'=>$done,'incidencias'=>count($errors)]);
            Response::json(['success'=>true,'message'=>$summary,'execution_id'=>$executionId,'analyzed'=>$done,'errors'=>$errors,'budget'=>$this->budget->status()]);
        } catch(Throwable $e) {
            $end=$this->pdo->prepare("UPDATE ejecuciones_agente SET estado='fallida',error_detalle=:error,fecha_fin=NOW() WHERE id=:id");$end->execute(['error'=>$e->getMessage(),'id'=>$executionId]);
            $this->event($executionId,'analisis_fallido','error','Ada no pudo completar el análisis.',['error'=>$e->getMessage()]);
            error_log('[NiarSales Ada run] '.$e->getMessage());
            Response::json(['success'=>false,'message'=>$e->getMessage()],500);
        }
    }
}
