<?php
declare(strict_types=1);

namespace NiarSales\Controllers;

use NiarSales\Core\Database;
use NiarSales\Core\Response;
use PDO;
use Throwable;

final class ProspectController
{
    private PDO $pdo;
    private array $columns = [];
    private array $agentConfig = [];

    public function __construct(array $dbConfig, array $agentConfig = [])
    {
        $this->pdo = Database::connection($dbConfig);
        $this->agentConfig = $agentConfig;
        $stmt = $this->pdo->query('SHOW COLUMNS FROM prospectos');
        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $column) {
            $this->columns[] = (string) $column['Field'];
        }
    }

    private function col(array $candidates, bool $required = false): ?string
    {
        foreach ($candidates as $candidate) {
            if (in_array($candidate, $this->columns, true)) return $candidate;
        }
        if ($required) {
            throw new \RuntimeException('No se encontró una columna esperada en la tabla prospectos: ' . implode('/', $candidates));
        }
        return null;
    }

    private function selectExpr(array $candidates, string $alias, string $fallback = 'NULL'): string
    {
        $column = $this->col($candidates);
        return $column ? "`{$column}` AS `{$alias}`" : "{$fallback} AS `{$alias}`";
    }

    private function input(): array
    {
        $raw = file_get_contents('php://input');
        $data = json_decode($raw ?: '{}', true);
        return is_array($data) ? $data : [];
    }

    private function csrf(): void
    {
        $provided = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
        $expected = $_SESSION['csrf_token'] ?? '';
        if (!is_string($provided) || !is_string($expected) || $provided === '' || $expected === '' || !hash_equals($expected, $provided)) {
            Response::json(['success' => false, 'message' => 'Token de seguridad inválido. Actualizá la sesión.'], 419);
        }
    }

    private function userId(): int
    {
        if (empty($_SESSION['user']['id'])) {
            Response::json(['success' => false, 'message' => 'La sesión expiró. Iniciá sesión nuevamente.'], 401);
        }
        return (int) $_SESSION['user']['id'];
    }

    private function normalizedSelect(): string
    {
        return implode(",\n", [
            $this->selectExpr(['id', 'ID'], 'id', '0'),
            $this->selectExpr(['nombre', 'nombre_comercial', 'comercio', 'empresa'], 'nombre', "''"),
            $this->selectExpr(['razon_social'], 'razon_social'),
            $this->selectExpr(['rubro_id', 'id_rubro'], 'rubro_id'),
            $this->selectExpr(['fuente_id', 'fuente_prospecto_id', 'id_fuente'], 'fuente_id'),
            $this->selectExpr(['sitio_web', 'web', 'website'], 'sitio_web'),
            $this->selectExpr(['instagram'], 'instagram'),
            $this->selectExpr(['facebook'], 'facebook'),
            $this->selectExpr(['telefono', 'teléfono', 'phone'], 'telefono'),
            $this->selectExpr(['telefono_original'], 'telefono_original'),
            $this->selectExpr(['telefono_tipo'], 'telefono_tipo', "'desconocido'"),
            $this->selectExpr(['email', 'correo'], 'email'),
            $this->selectExpr(['direccion', 'domicilio'], 'direccion'),
            $this->selectExpr(['localidad', 'ciudad'], 'localidad'),
            $this->selectExpr(['provincia'], 'provincia'),
            $this->selectExpr(['codigo_postal'], 'codigo_postal'),
            $this->selectExpr(['pais'], 'pais', "'Argentina'"),
            $this->selectExpr(['estado'], 'estado', "'nuevo'"),
            $this->selectExpr(['prioridad'], 'prioridad', "'media'"),
            $this->selectExpr(['score', 'puntaje'], 'score', '0'),
            $this->selectExpr(['mensaje_sugerido_ia'], 'mensaje_sugerido_ia'),
            $this->selectExpr(['google_place_id', 'place_id'], 'google_place_id'),
            $this->selectExpr(['google_maps_url', 'url_google_maps'], 'google_maps_url'),
            $this->selectExpr(['notas', 'observaciones'], 'notas'),
            $this->selectExpr(['creado_por', 'usuario_creador_id'], 'creado_por'),
            $this->selectExpr(['asignado_a', 'usuario_asignado_id'], 'asignado_a'),
            $this->selectExpr(['ada_puntuacion'], 'ada_puntuacion'),
            $this->selectExpr(['ada_prioridad'], 'ada_prioridad'),
            $this->selectExpr(['ada_resumen'], 'ada_resumen'),
            $this->selectExpr(['ada_recomendacion'], 'ada_recomendacion'),
            $this->selectExpr(['ada_analisis_json'], 'ada_analisis_json'),
            $this->selectExpr(['ada_analizado_at'], 'ada_analizado_at'),
            $this->selectExpr(['created_at', 'fecha_creacion', 'fecha_alta'], 'created_at'),
            $this->selectExpr(['updated_at', 'fecha_actualizacion', 'fecha_modificacion'], 'updated_at'),
        ]);
    }

    public function list(): never
    {
        $this->userId();
        try {
            $where = [];
            $params = [];
            $nameCol = $this->col(['nombre', 'nombre_comercial', 'comercio', 'empresa']);
            $localityCol = $this->col(['localidad', 'ciudad']);
            $stateCol = $this->col(['estado']);
            $rubroCol = $this->col(['rubro_id', 'id_rubro']);
            $priorityCol = $this->col(['prioridad']);
            $adaDateCol = $this->col(['ada_analizado_at']);

            $q = trim((string)($_GET['q'] ?? ''));
            if ($q !== '' && $nameCol) {
                $where[] = "`{$nameCol}` LIKE :q";
                $params['q'] = '%' . $q . '%';
            }
            foreach ([
                'estado' => $stateCol,
                'localidad' => $localityCol,
                'rubro_id' => $rubroCol,
                'prioridad' => $priorityCol,
            ] as $key => $column) {
                $value = trim((string)($_GET[$key] ?? ''));
                if ($value !== '' && $column) {
                    $where[] = "`{$column}` = :{$key}";
                    $params[$key] = $value;
                }
            }

            $adaFilter = trim((string)($_GET['ada_estado'] ?? ''));
            if ($adaFilter !== '' && $adaDateCol && in_array($adaFilter, ['analizado','pendiente'], true)) {
                $where[] = $adaFilter === 'analizado' ? "`{$adaDateCol}` IS NOT NULL" : "`{$adaDateCol}` IS NULL";
            }

            $page = max(1, (int)($_GET['page'] ?? 1));
            $perPage = min(100, max(5, (int)($_GET['per_page'] ?? 15)));
            $clause = $where ? ' WHERE ' . implode(' AND ', $where) : '';

            $count = $this->pdo->prepare("SELECT COUNT(*) FROM prospectos{$clause}");
            $count->execute($params);
            $total = (int)$count->fetchColumn();

            $orderCol = $this->col(['created_at', 'fecha_creacion', 'fecha_alta', 'id', 'ID'], true);
            $sql = 'SELECT ' . $this->normalizedSelect() . " FROM prospectos{$clause} ORDER BY `{$orderCol}` DESC LIMIT :limit OFFSET :offset";
            $stmt = $this->pdo->prepare($sql);
            foreach ($params as $key => $value) $stmt->bindValue(':' . $key, $value);
            $stmt->bindValue(':limit', $perPage, PDO::PARAM_INT);
            $stmt->bindValue(':offset', ($page - 1) * $perPage, PDO::PARAM_INT);
            $stmt->execute();

            Response::json([
                'success' => true,
                'data' => $stmt->fetchAll(PDO::FETCH_ASSOC),
                'pagination' => ['page' => $page, 'per_page' => $perPage, 'total' => $total, 'pages' => (int)ceil($total / $perPage)]
            ]);
        } catch (Throwable $e) {
            error_log('[NiarSales prospect list] ' . $e->getMessage());
            Response::json(['success' => false, 'message' => 'No se pudo obtener el listado de prospectos. Revisá el registro de errores.'], 500);
        }
    }

    public function catalogs(): never
    {
        $this->userId();
        try {
            $rubros = $this->pdo->query('SELECT * FROM rubros ORDER BY nombre')->fetchAll(PDO::FETCH_ASSOC);
            $fuentes = $this->pdo->query('SELECT * FROM fuentes_prospectos ORDER BY nombre')->fetchAll(PDO::FETCH_ASSOC);
            Response::json(['success' => true, 'rubros' => $rubros, 'fuentes' => $fuentes]);
        } catch (Throwable $e) {
            error_log('[NiarSales prospect catalogs] ' . $e->getMessage());
            Response::json(['success' => false, 'message' => 'No se pudieron cargar los rubros y las fuentes.'], 500);
        }
    }

    /** Normaliza el teléfono cuando el usuario confirma manualmente el tipo de línea. */
    private function normalizePhoneForType(string $phone, string $type): string
    {
        $digits = preg_replace('/\D+/', '', $phone) ?? '';
        if (str_starts_with($digits, '00')) $digits = substr($digits, 2);
        if ($digits === '') return '';

        if ($type === 'celular') {
            if (str_starts_with($digits, '549')) return $digits;
            if (str_starts_with($digits, '54')) return '549' . substr($digits, 2);
            if (str_starts_with($digits, '0')) $digits = substr($digits, 1);
            return '549' . $digits;
        }

        if ($type === 'fijo') {
            if (str_starts_with($digits, '549')) return '54' . substr($digits, 3);
            if (str_starts_with($digits, '54')) return $digits;
            if (str_starts_with($digits, '0')) $digits = substr($digits, 1);
            return '54' . $digits;
        }

        return $digits;
    }

    public function save(?int $id = null): never
    {
        $userId = $this->userId();
        $this->csrf();
        try {
            $data = $this->input();
            $map = [
                'nombre' => ['nombre', 'nombre_comercial', 'comercio', 'empresa'],
                'razon_social' => ['razon_social'],
                'rubro_id' => ['rubro_id', 'id_rubro'],
                'fuente_id' => ['fuente_id', 'fuente_prospecto_id', 'id_fuente'],
                'sitio_web' => ['sitio_web', 'web', 'website'],
                'instagram' => ['instagram'], 'facebook' => ['facebook'],
                'telefono' => ['telefono', 'teléfono', 'phone'],
                'telefono_tipo' => ['telefono_tipo'],
                'email' => ['email', 'correo'],
                'direccion' => ['direccion', 'domicilio'],
                'localidad' => ['localidad', 'ciudad'],
                'provincia' => ['provincia'], 'codigo_postal' => ['codigo_postal'],
                'pais' => ['pais'], 'estado' => ['estado'], 'prioridad' => ['prioridad'],
                'notas' => ['notas', 'observaciones'], 'asignado_a' => ['asignado_a', 'usuario_asignado_id']
            ];
            $values = [];
            foreach ($map as $apiKey => $candidates) {
                $column = $this->col($candidates);
                if ($column && array_key_exists($apiKey, $data)) $values[$column] = $data[$apiKey];
            }

            // La selección manual del tipo de línea es la confirmación del usuario.
            // Al marcar celular/fijo, dejamos el número en formato internacional coherente.
            if (isset($data['telefono_tipo']) && in_array($data['telefono_tipo'], ['celular', 'fijo', 'desconocido'], true)) {
                $phoneColumn = $this->col(['telefono', 'teléfono', 'phone']);
                if ($phoneColumn && array_key_exists($phoneColumn, $values)) {
                    $values[$phoneColumn] = $this->normalizePhoneForType((string)$values[$phoneColumn], (string)$data['telefono_tipo']);
                }
            }

            $nameColumn = $this->col(['nombre', 'nombre_comercial', 'comercio', 'empresa'], true);
            $name = trim((string)($data['nombre'] ?? ''));
            if ($name === '') Response::json(['success' => false, 'message' => 'El nombre del comercio es obligatorio.'], 422);
            $values[$nameColumn] = $name;

            if (isset($values[$this->col(['email', 'correo']) ?? '__missing__']) && !filter_var((string)$values[$this->col(['email', 'correo'])], FILTER_VALIDATE_EMAIL)) {
                Response::json(['success' => false, 'message' => 'El correo electrónico no tiene un formato válido.'], 422);
            }

            if ($id !== null) {
                $idColumn = $this->col(['id', 'ID'], true);
                $sets = [];
                foreach ($values as $column => $value) $sets[] = "`{$column}` = :{$column}";
                $updated = $this->col(['updated_at', 'fecha_actualizacion', 'fecha_modificacion']);
                if ($updated) $sets[] = "`{$updated}` = NOW()";
                $values['__id'] = $id;
                $stmt = $this->pdo->prepare('UPDATE prospectos SET ' . implode(', ', $sets) . " WHERE `{$idColumn}` = :__id");
                $stmt->execute($values);
                $phoneColumn = $this->col(['telefono', 'teléfono', 'phone']);
                $typeColumn = $this->col(['telefono_tipo']);
                Response::json([
                    'success' => true,
                    'message' => 'Prospecto actualizado correctamente.',
                    'data' => [
                        'telefono' => $phoneColumn ? ($values[$phoneColumn] ?? null) : null,
                        'telefono_tipo' => $typeColumn ? ($values[$typeColumn] ?? null) : null,
                    ],
                ]);
            }

            $createdBy = $this->col(['creado_por', 'usuario_creador_id']);
            if ($createdBy) $values[$createdBy] = $userId;
            $createdAt = $this->col(['created_at', 'fecha_creacion', 'fecha_alta']);
            if ($createdAt) $values[$createdAt] = date('Y-m-d H:i:s');
            $columns = array_keys($values);
            $placeholders = array_map(static fn($c) => ':' . $c, $columns);
            $stmt = $this->pdo->prepare('INSERT INTO prospectos (`' . implode('`,`', $columns) . '`) VALUES (' . implode(',', $placeholders) . ')');
            $stmt->execute($values);
            Response::json(['success' => true, 'message' => 'Prospecto creado correctamente.', 'id' => (int)$this->pdo->lastInsertId()], 201);
        } catch (Throwable $e) {
            error_log('[NiarSales prospect save] ' . $e->getMessage());
            Response::json(['success' => false, 'message' => 'No se pudo guardar el prospecto. Revisá los datos y el registro de errores.'], 500);
        }
    }


    /** Consulta bajo demanda el resumen oficial de reseñas de Google.
     * El contenido se devuelve solo para la vista actual: no se persiste en MySQL.
     */
    public function reviewSummary(int $id): never
    {
        $this->userId();
        try {
            $idColumn = $this->col(['id', 'ID'], true);
            $placeColumn = $this->col(['google_place_id', 'place_id']);
            if (!$placeColumn) {
                Response::json(['success' => false, 'message' => 'La tabla de prospectos no tiene configurado el identificador de Google Places.'], 422);
            }
            $stmt = $this->pdo->prepare("SELECT `{$placeColumn}` FROM prospectos WHERE `{$idColumn}` = :id LIMIT 1");
            $stmt->execute(['id' => $id]);
            $placeId = (string)($stmt->fetchColumn() ?: '');
            if ($placeId === '') {
                Response::json(['success' => false, 'message' => 'Este prospecto no tiene un Google Place ID asociado. No se puede consultar su resumen de reseñas.'], 422);
            }

            $key = (string)($this->agentConfig['google_places_api_key'] ?? '');
            if ($key === '' || str_starts_with($key, 'PEGAR_')) {
                Response::json(['success' => false, 'message' => 'Falta configurar google_places_api_key en api/config/agent.php.'], 503);
            }
            if (!function_exists('curl_init')) {
                Response::json(['success' => false, 'message' => 'El servidor no tiene habilitada la extensión cURL de PHP.'], 503);
            }

            $url = 'https://places.googleapis.com/v1/places/' . rawurlencode($placeId) . '?languageCode=es';
            $ch = curl_init($url);
            curl_setopt_array($ch, [
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_TIMEOUT => 20,
                CURLOPT_CONNECTTIMEOUT => 8,
                CURLOPT_HTTPHEADER => [
                    'X-Goog-Api-Key: ' . $key,
                    'X-Goog-FieldMask: id,displayName,rating,userRatingCount,googleMapsUri,reviewSummary.text,reviewSummary.flagContentUri,reviewSummary.disclosureText,reviewSummary.reviewsUri',
                ],
            ]);
            $raw = curl_exec($ch);
            $status = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $curlError = curl_error($ch);
            curl_close($ch);
            if ($raw === false) {
                error_log('[NiarSales Google review summary] ' . $curlError);
                Response::json(['success' => false, 'message' => 'No se pudo conectar con Google Places.'], 502);
            }
            $data = json_decode((string)$raw, true);
            if ($status < 200 || $status >= 300 || !is_array($data)) {
                $googleMessage = is_array($data) ? (string)($data['error']['message'] ?? '') : '';
                error_log('[NiarSales Google review summary] HTTP ' . $status . ' ' . $googleMessage);
                Response::json(['success' => false, 'message' => $status === 404 ? 'Google no encontró el comercio asociado a este identificador.' : 'Google Places no pudo devolver el resumen de reseñas. Verificá la API y sus permisos.'], $status >= 400 && $status < 500 ? 502 : 502);
            }

            $summary = $data['reviewSummary'] ?? null;
            Response::json([
                'success' => true,
                'available' => is_array($summary) && trim((string)($summary['text']['text'] ?? '')) !== '',
                'data' => [
                    'name' => $data['displayName']['text'] ?? null,
                    'rating' => $data['rating'] ?? null,
                    'user_rating_count' => $data['userRatingCount'] ?? null,
                    'summary_text' => $summary['text']['text'] ?? null,
                    'disclosure_text' => $summary['disclosureText']['text'] ?? null,
                    'reviews_uri' => $summary['reviewsUri'] ?? $data['googleMapsUri'] ?? null,
                    'flag_content_uri' => $summary['flagContentUri'] ?? null,
                    'source' => 'Google Places',
                ],
                'message' => is_array($summary) ? 'Google devolvió su resumen automático de reseñas.' : 'Google no tiene un resumen automático disponible para este comercio.',
            ]);
        } catch (Throwable $e) {
            error_log('[NiarSales prospect review summary] ' . $e->getMessage());
            Response::json(['success' => false, 'message' => 'No se pudo consultar el resumen de reseñas. Revisá el registro de errores.'], 500);
        }
    }

    public function detail(int $id): never
    {
        $this->userId();
        try {
            $idColumn = $this->col(['id', 'ID'], true);
            $stmt = $this->pdo->prepare('SELECT ' . $this->normalizedSelect() . " FROM prospectos WHERE `{$idColumn}` = :id LIMIT 1");
            $stmt->execute(['id' => $id]);
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            if (!$row) Response::json(['success' => false, 'message' => 'No se encontró el prospecto.'], 404);
            Response::json(['success' => true, 'data' => $row]);
        } catch (Throwable $e) {
            error_log('[NiarSales prospect detail] ' . $e->getMessage());
            Response::json(['success' => false, 'message' => 'No se pudo obtener el prospecto.'], 500);
        }
    }
}
