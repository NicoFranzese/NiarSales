<?php
declare(strict_types=1);

namespace NiarSales\Controllers;

use NiarSales\Core\Database;
use NiarSales\Core\Response;
use PDO;
use Throwable;

final class AuthController
{
    private function input(): array
    {
        $raw = file_get_contents('php://input');
        if ($raw === false || $raw === '') {
            return [];
        }

        $data = json_decode($raw, true);
        return is_array($data) ? $data : [];
    }

    private function csrfToken(): string
    {
        if (empty($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }
        return (string) $_SESSION['csrf_token'];
    }

    private function requireCsrf(): void
    {
        $provided = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
        $expected = $_SESSION['csrf_token'] ?? '';

        if (!is_string($provided) || !is_string($expected) ||
            $provided === '' || $expected === '' ||
            !hash_equals($expected, $provided)) {
            Response::json([
                'success' => false,
                'message' => 'Token de seguridad inválido. Actualizá la sesión e intentá nuevamente.'
            ], 419);
        }
    }

    public function login(array $dbConfig): never
    {
        $data = $this->input();
        $email = strtolower(trim((string) ($data['email'] ?? '')));
        $password = (string) ($data['password'] ?? '');

        if (!filter_var($email, FILTER_VALIDATE_EMAIL) || $password === '' || strlen($password) > 4096) {
            Response::json([
                'success' => false,
                'message' => 'Ingresá un email y una contraseña válidos.'
            ], 422);
        }

        try {
            $pdo = Database::connection($dbConfig);
            $statement = $pdo->prepare(
                'SELECT id, nombre, email, password_hash, rol, activo
                 FROM usuarios
                 WHERE email = :email
                 LIMIT 1'
            );
            $statement->execute(['email' => $email]);
            $user = $statement->fetch(PDO::FETCH_ASSOC);

            if (!$user || (int) $user['activo'] !== 1 ||
                !password_verify($password, (string) $user['password_hash'])) {
                usleep(350000);
                Response::json([
                    'success' => false,
                    'message' => 'Email o contraseña incorrectos.'
                ], 401);
            }

            session_regenerate_id(true);
            $_SESSION['user'] = [
                'id' => (int) $user['id'],
                'nombre' => (string) $user['nombre'],
                'email' => (string) $user['email'],
                'rol' => (string) $user['rol'],
            ];
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));

            $update = $pdo->prepare('UPDATE usuarios SET ultimo_acceso = NOW() WHERE id = :id');
            $update->execute(['id' => (int) $user['id']]);

            Response::json([
                'success' => true,
                'message' => 'Sesión iniciada correctamente.',
                'user' => $_SESSION['user'],
                'csrf_token' => $_SESSION['csrf_token']
            ]);
        } catch (Throwable $exception) {
            error_log('[NiarSales login] ' . $exception->getMessage());
            Response::json([
                'success' => false,
                'message' => 'No se pudo procesar el inicio de sesión.'
            ], 500);
        }
    }

    public function me(): never
    {
        if (empty($_SESSION['user'])) {
            Response::json([
                'success' => false,
                'authenticated' => false,
                'message' => 'No hay una sesión iniciada.'
            ], 401);
        }

        Response::json([
            'success' => true,
            'authenticated' => true,
            'user' => $_SESSION['user'],
            'csrf_token' => $this->csrfToken()
        ]);
    }

    public function logout(): never
    {
        $this->requireCsrf();

        $_SESSION = [];

        if (ini_get('session.use_cookies')) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', [
                'expires' => time() - 42000,
                'path' => $params['path'],
                'domain' => $params['domain'],
                'secure' => (bool) $params['secure'],
                'httponly' => (bool) $params['httponly'],
                'samesite' => $params['samesite'] ?? 'Lax',
            ]);
        }

        session_destroy();

        Response::json([
            'success' => true,
            'message' => 'Sesión cerrada correctamente.'
        ]);
    }
}
