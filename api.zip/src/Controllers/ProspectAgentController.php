<?php
declare(strict_types=1);
namespace NiarSales\Controllers;
use NiarSales\Core\Database;
use NiarSales\Core\BudgetService;
use NiarSales\Core\Response;
use PDO;
use RuntimeException;
use Throwable;
final class ProspectAgentController {
 private PDO $pdo; private array $cfg; private BudgetService $budget;
 public function __construct(array $dbConfig,array $agentConfig){$this->pdo=Database::connection($dbConfig);$this->cfg=$agentConfig;$this->budget=new BudgetService($this->pdo);}
 private function userId():int{if(empty($_SESSION['user']['id']))Response::json(['success'=>false,'message'=>'La sesión expiró.'],401);return (int)$_SESSION['user']['id'];}
 private function writeUser():int{$id=$this->userId();$got=$_SERVER['HTTP_X_CSRF_TOKEN']??'';$exp=$_SESSION['csrf_token']??'';if(!is_string($got)||!is_string($exp)||$got===''||$exp===''||!hash_equals($exp,$got))Response::json(['success'=>false,'message'=>'Token de seguridad inválido.'],419);return $id;}
 private function input():array{$v=json_decode((string)file_get_contents('php://input'),true);return is_array($v)?$v:[];}
 private function prospect(int $id):array{$q=$this->pdo->prepare('SELECT p.*,r.nombre AS rubro_nombre FROM prospectos p LEFT JOIN rubros r ON r.id=p.rubro_id WHERE p.id=:id LIMIT 1');$q->execute(['id'=>$id]);$p=$q->fetch(PDO::FETCH_ASSOC);if(!$p)Response::json(['success'=>false,'message'=>'No se encontró el prospecto.'],404);if(!empty($p['ada_analisis_json']))$p['ada_analisis']=json_decode((string)$p['ada_analisis_json'],true)?:null;return $p;}
 private function activities(int $id):array{$q=$this->pdo->prepare('SELECT tipo,canal,resultado,detalle,mensaje,proximo_contacto,created_at FROM prospecto_actividades WHERE prospecto_id=:id ORDER BY created_at DESC,id DESC LIMIT 20');$q->execute(['id'=>$id]);return $q->fetchAll(PDO::FETCH_ASSOC);}
 private function callModel(string $agent,array $p,array $acts,array $input):array{
  $key=(string)($this->cfg['openai_api_key']??'');if($key===''||str_starts_with($key,'PEGAR_'))throw new RuntimeException('Falta configurar OpenAI API en api/config/agent.php.');if(!function_exists('curl_init'))throw new RuntimeException('La extensión cURL de PHP no está habilitada.');
  $product=(string)($this->cfg['product_name']??'MesAPP');$desc=(string)($this->cfg['product_description']??'Menú digital y gestión de pedidos.');
  if($agent==='ventas'){$system='Sos Leo, especialista comercial B2B de NiarSales. Preparás un primer mensaje personalizado para ofrecer '.$product.'. Usá solo información recibida; no inventes que visitaste el local ni verificaste redes o funciones. Tono argentino, cálido, profesional, breve y natural para WhatsApp. No prometas resultados ni hagas spam. Respondé JSON válido con: asunto, mensaje, enfoque, personalizacion (array de evidencias usadas), advertencias (array de cosas que no deben afirmarse). Es un borrador para revisión humana, nunca enviar.';$user='Producto: '.$product.'. '.$desc."\nProspecto, análisis Ada e investigación Ivo:\n".json_encode($p,JSON_UNESCAPED_UNICODE)."\nHistorial comercial:\n".json_encode($acts,JSON_UNESCAPED_UNICODE)."\nInstrucción adicional: ".trim((string)($input['instruccion']??'Ninguna'));$max=500;}
  else{$system='Sos Mia, agente de seguimiento comercial B2B. Usá estado e historial real. No afirmes que se envió algo si no está registrado. No contactes a nadie. Proponé un próximo paso prudente y un borrador breve. Si respondió o pidió no ser contactado, respetalo. Respondé JSON válido con: accion_recomendada, motivo, canal (whatsapp|telefono|email|instagram|facebook|interno), dias_hasta_seguimiento (entero 0-30 o null), fecha_sugerida (YYYY-MM-DD o null), mensaje, condicion, no_contactar (boolean).';$user='Prepará un plan, sin ejecutarlo ni enviar mensajes. Prospecto: '.json_encode($p,JSON_UNESCAPED_UNICODE)."\nActividades más recientes primero: ".json_encode($acts,JSON_UNESCAPED_UNICODE)."\nInstrucción: ".trim((string)($input['instruccion']??'Evaluar el próximo paso más prudente.'));$max=450;}
  $model=(string)($this->cfg['openai_model']??'gpt-4.1-mini');$payload=['model'=>$model,'messages'=>[['role'=>'system','content'=>$system],['role'=>'user','content'=>$user]],'response_format'=>['type'=>'json_object'],'temperature'=>0.25,'max_tokens'=>$max];$estimate=(int)ceil((strlen($system)+strlen($user))/3*1.25);$reservation=$this->budget->reserve($model,$estimate,$max);
  try{$ch=curl_init('https://api.openai.com/v1/chat/completions');curl_setopt_array($ch,[CURLOPT_POST=>true,CURLOPT_RETURNTRANSFER=>true,CURLOPT_POSTFIELDS=>json_encode($payload),CURLOPT_HTTPHEADER=>['Content-Type: application/json','Authorization: Bearer '.$key],CURLOPT_TIMEOUT=>45]);$body=curl_exec($ch);$status=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);$err=curl_error($ch);curl_close($ch);if($body===false)throw new RuntimeException('No se pudo consultar OpenAI: '.$err);$json=json_decode((string)$body,true);if($status<200||$status>=300)throw new RuntimeException('OpenAI rechazó la solicitud: '.($json['error']['message']??('HTTP '.$status)));$result=json_decode((string)($json['choices'][0]['message']['content']??''),true);if(!is_array($result))throw new RuntimeException('Respuesta del agente inválida.');$in=(int)($json['usage']['prompt_tokens']??0);$out=(int)($json['usage']['completion_tokens']??0);$cost=$this->budget->settle($reservation,(string)($json['model']??$model),$in,$out);$result['_usage']=['model'=>$json['model']??$model,'input_tokens'=>$in,'output_tokens'=>$out,'cost_usd'=>$cost];return $result;}catch(Throwable $e){$this->budget->release($reservation,$e->getMessage());throw $e;}
 }
 private function beginExecution(int $user,int $pid,string $agent):int{
  $type=$agent==='ventas'?'generacion_mensaje':'seguimiento';
  $title=$agent==='ventas'?'Leo prepara un mensaje comercial':'Mia prepara un plan de seguimiento';
  $q=$this->pdo->prepare("INSERT INTO ejecuciones_agente (tipo,estado,iniciado_por,objetivo,parametros_json,cantidad_prospectos,fecha_inicio,created_at) VALUES (:type,'ejecutando',:user,:objective,:params,1,NOW(),NOW())");
  $q->execute(['type'=>$type,'user'=>$user,'objective'=>$title.' para prospecto #'.$pid,'params'=>json_encode(['agente'=>$agent,'prospecto_id'=>$pid],JSON_UNESCAPED_UNICODE)]);
  $id=(int)$this->pdo->lastInsertId();
  $e=$this->pdo->prepare("INSERT INTO eventos_agente (agente_slug,ejecucion_id,tipo,estado,mensaje,detalle_json,created_at) VALUES (:agent,:id,'tarea_iniciada','working',:message,:detail,NOW())");
  $e->execute(['agent'=>$agent,'id'=>$id,'message'=>$title.'.','detail'=>json_encode(['prospecto_id'=>$pid])]);
  return $id;
 }
 private function saveWork(int $user,int $pid,int $execution,string $agent,string $kind,array $result,array $context):int{
  $this->pdo->beginTransaction();try{$title=$agent==='ventas'?'Leo preparó un mensaje comercial':'Mia preparó un plan de seguimiento';$q=$this->pdo->prepare("INSERT INTO prospecto_trabajos_agente (prospecto_id,ejecucion_id,agente_slug,tipo,estado,titulo,contenido_json,contexto_json,creado_por,created_at) VALUES (:pid,:eid,:agent,:type,'borrador',:title,:content,:context,:user,NOW())");$q->execute(['pid'=>$pid,'eid'=>$execution,'agent'=>$agent,'type'=>$kind,'title'=>$title,'content'=>json_encode($result,JSON_UNESCAPED_UNICODE),'context'=>json_encode($context,JSON_UNESCAPED_UNICODE),'user'=>$user]);$work=(int)$this->pdo->lastInsertId();$done=$this->pdo->prepare("UPDATE ejecuciones_agente SET estado='completada',resultado_resumen=:summary,cantidad_prospectos=1,fecha_fin=NOW() WHERE id=:id");$done->execute(['summary'=>$title.' para prospecto #'.$pid,'id'=>$execution]);$ev=$this->pdo->prepare("INSERT INTO eventos_agente (agente_slug,ejecucion_id,tipo,estado,mensaje,detalle_json,created_at) VALUES (:agent,:eid,:type,'success',:message,:detail,NOW())");$ev->execute(['agent'=>$agent,'eid'=>$execution,'type'=>$kind,'message'=>$title.'. Guardado en la ficha del prospecto.','detail'=>json_encode(['prospecto_id'=>$pid,'trabajo_id'=>$work],JSON_UNESCAPED_UNICODE)]);$this->pdo->commit();return $work;}catch(Throwable $e){if($this->pdo->inTransaction())$this->pdo->rollBack();throw $e;}
 }
 public function list(int $pid):never{$this->userId();try{$p=$this->prospect($pid);$q=$this->pdo->prepare('SELECT id,prospecto_id,ejecucion_id,agente_slug,tipo,estado,titulo,contenido_json,created_at FROM prospecto_trabajos_agente WHERE prospecto_id=:id ORDER BY id DESC');$q->execute(['id'=>$pid]);$works=$q->fetchAll(PDO::FETCH_ASSOC);foreach($works as &$r){$r['contenido']=json_decode((string)$r['contenido_json'],true)?:[];unset($r['contenido_json']);}unset($r);$q=$this->pdo->prepare('SELECT id,ejecucion_id,tipo,titulo,contenido,datos_json,created_at FROM resultados_agente WHERE prospecto_id=:id ORDER BY id DESC');$q->execute(['id'=>$pid]);$results=$q->fetchAll(PDO::FETCH_ASSOC);foreach($results as &$r){$r['datos']=json_decode((string)($r['datos_json']??''),true)?:[];unset($r['datos_json']);$r['agente']=($r['tipo']==='analisis'||str_starts_with((string)$r['titulo'],'Ada'))?'analista':'investigador';}unset($r);Response::json(['success'=>true,'data'=>['prospect'=>$p,'works'=>$works,'results'=>$results]]);}catch(Throwable $e){error_log('[NiarSales agent work list] '.$e->getMessage());Response::json(['success'=>false,'message'=>'No se pudo cargar el historial de agentes del prospecto.'],500);}}
 public function run(int $pid,string $agent):never{
  $user=$this->writeUser();
  if(!in_array($agent,['ventas','seguimiento'],true))Response::json(['success'=>false,'message'=>'Agente no válido.'],422);
  $input=$this->input();$execution=0;
  try{
   $active=$this->pdo->query("SELECT id FROM ejecuciones_agente WHERE estado IN ('ejecutando','pendiente') ORDER BY id DESC LIMIT 1")->fetchColumn();
   if($active)Response::json(['success'=>false,'message'=>'Hay otra tarea en curso (ejecución #'.(int)$active.'). Esperá a que termine.'],409);
   $p=$this->prospect($pid);$acts=$this->activities($pid);
   if($agent==='seguimiento'&&in_array((string)($p['estado']??''),['no_interesado','cliente'],true))Response::json(['success'=>false,'message'=>'Mia no recomienda nuevos seguimientos para prospectos marcados como no interesados o clientes.'],409);
   $execution=$this->beginExecution($user,$pid,$agent);
   if(session_status()===PHP_SESSION_ACTIVE)session_write_close();
   $result=$this->callModel($agent,$p,$acts,$input);
   if($agent==='ventas'){
    $msg=trim((string)($result['mensaje']??''));if($msg==='')throw new RuntimeException('Leo no generó un mensaje válido.');
    $up=$this->pdo->prepare('UPDATE prospectos SET mensaje_sugerido_ia=:msg WHERE id=:id');$up->execute(['msg'=>$msg,'id'=>$pid]);$kind='mensaje_comercial';
   }else{$kind='plan_seguimiento';if(!empty($result['no_contactar'])){$result['fecha_sugerida']=null;$result['dias_hasta_seguimiento']=null;}}
   $work=$this->saveWork($user,$pid,$execution,$agent,$kind,$result,['prospecto'=>$p,'actividades'=>$acts]);
   Response::json(['success'=>true,'message'=>$agent==='ventas'?'Leo preparó un borrador. Revisalo antes de enviarlo.':'Mia preparó un plan. No se envió ningún mensaje.','data'=>['work_id'=>$work,'agent'=>$agent,'result'=>$result],'budget'=>$this->budget->status()]);
  }catch(Throwable $e){
   if($execution>0){try{$q=$this->pdo->prepare("UPDATE ejecuciones_agente SET estado='fallida',error_detalle=:err,fecha_fin=NOW() WHERE id=:id");$q->execute(['err'=>$e->getMessage(),'id'=>$execution]);$q=$this->pdo->prepare("INSERT INTO eventos_agente (agente_slug,ejecucion_id,tipo,estado,mensaje,detalle_json,created_at) VALUES (:agent,:id,'tarea_fallida','error','El agente no pudo completar la tarea.',:detail,NOW())");$q->execute(['agent'=>$agent,'id'=>$execution,'detail'=>json_encode(['error'=>$e->getMessage(),'prospecto_id'=>$pid])]);}catch(Throwable $logError){error_log('[NiarSales agent execution update] '.$logError->getMessage());}}
   error_log('[NiarSales agent '.$agent.'] '.$e->getMessage());Response::json(['success'=>false,'message'=>$e->getMessage()],500);
  }
 }
}
