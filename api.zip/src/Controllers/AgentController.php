<?php
declare(strict_types=1);

namespace NiarSales\Controllers;

use NiarSales\Core\Database;
use NiarSales\Core\BudgetService;
use NiarSales\Core\BudgetExceededException;
use NiarSales\Core\Response;
use PDO;
use RuntimeException;
use Throwable;

final class AgentController
{
    private PDO $pdo;
    private array $cfg;
    private BudgetService $budget;
    private array $prospectColumns = [];

    public function __construct(array $dbConfig, array $agentConfig)
    {
        $this->pdo = Database::connection($dbConfig);
        $this->cfg = $agentConfig;
        $this->budget = new BudgetService($this->pdo);
        $q = $this->pdo->query('SHOW COLUMNS FROM prospectos');
        foreach ($q->fetchAll(PDO::FETCH_ASSOC) as $c) $this->prospectColumns[] = (string)$c['Field'];
    }

    private function requireUser(): int
    {
        if (empty($_SESSION['user']['id'])) Response::json(['success'=>false,'message'=>'La sesión expiró. Iniciá sesión nuevamente.'], 401);
        return (int)$_SESSION['user']['id'];
    }

    private function requireCsrf(): void
    {
        $got = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
        $expected = $_SESSION['csrf_token'] ?? '';
        if (!is_string($got) || !is_string($expected) || $got === '' || $expected === '' || !hash_equals($expected, $got)) {
            Response::json(['success'=>false,'message'=>'Token de seguridad inválido. Actualizá la sesión.'], 419);
        }
    }

    private function input(): array
    {
        $data = json_decode((string)file_get_contents('php://input'), true);
        return is_array($data) ? $data : [];
    }

    private function col(array $candidates, bool $required=false): ?string
    {
        foreach ($candidates as $c) if (in_array($c, $this->prospectColumns, true)) return $c;
        if ($required) throw new RuntimeException('La tabla prospectos no tiene la columna esperada: '.implode('/', $candidates));
        return null;
    }

    private function insertDynamic(string $table, array $candidates, array $values): ?int
    {
        $columns = [];
        $data = [];
        foreach ($values as $key => $value) {
            foreach ($candidates[$key] ?? [$key] as $candidate) {
                if ($this->columnExists($table, $candidate)) {
                    $columns[$candidate] = true;
                    $data[$candidate] = $value;
                    break;
                }
            }
        }
        if (!$data) return null;
        $names = array_keys($data);
        $sql = 'INSERT INTO `'.$table.'` (`'.implode('`,`',$names).'`) VALUES (:'.implode(',:',$names).')';
        $st = $this->pdo->prepare($sql);
        foreach ($data as $k=>$v) $st->bindValue(':'.$k, $v);
        $st->execute();
        return (int)$this->pdo->lastInsertId();
    }

    private array $tableColumns = [];
    private function columnExists(string $table, string $column): bool
    {
        if (!isset($this->tableColumns[$table])) {
            $q = $this->pdo->query("SHOW COLUMNS FROM `".$table."`");
            $this->tableColumns[$table] = array_column($q->fetchAll(PDO::FETCH_ASSOC), 'Field');
        }
        return in_array($column, $this->tableColumns[$table], true);
    }

    private function saveExecution(string $status, string $objective, array $params, ?string $summary=null, ?string $error=null, int $found=0, int $saved=0): ?int
    {
        try {
            $state = ['en_proceso'=>'ejecutando','ejecutando'=>'ejecutando','completada'=>'completada','error'=>'fallida','fallida'=>'fallida','pendiente'=>'pendiente'][$status] ?? 'pendiente';
            $st = $this->pdo->prepare(
                'INSERT INTO ejecuciones_agente (tipo, estado, iniciado_por, objetivo, parametros_json, resultado_resumen, error_detalle, cantidad_prospectos, fecha_inicio, fecha_fin)
'
                . 'VALUES (:tipo, :estado, :usuario, :objetivo, :parametros, :resumen, :error, :cantidad, NOW(), :fecha_fin)'
            );
            $st->execute([
                ':tipo'=>'busqueda', ':estado'=>$state, ':usuario'=>$_SESSION['user']['id'] ?? null,
                ':objetivo'=>$objective, ':parametros'=>json_encode($params, JSON_UNESCAPED_UNICODE),
                ':resumen'=>$summary, ':error'=>$error, ':cantidad'=>$found,
                ':fecha_fin'=>$state === 'ejecutando' || $state === 'pendiente' ? null : date('Y-m-d H:i:s'),
            ]);
            return (int)$this->pdo->lastInsertId();
        } catch (Throwable $e) {
            error_log('[NiarSales execution log] '.$e->getMessage());
            return null;
        }
    }

    private function updateExecution(?int $executionId, string $status, ?string $summary=null, ?string $error=null, int $found=0, int $saved=0): void
    {
        if (!$executionId) return;
        try {
            $state = ['en_proceso'=>'ejecutando','ejecutando'=>'ejecutando','completada'=>'completada','error'=>'fallida','fallida'=>'fallida','pendiente'=>'pendiente'][$status] ?? 'pendiente';
            $st = $this->pdo->prepare(
                'UPDATE ejecuciones_agente SET estado=:estado, resultado_resumen=:resumen, error_detalle=:error, cantidad_prospectos=:cantidad, fecha_fin=:fecha_fin WHERE id=:id'
            );
            $st->execute([
                ':estado'=>$state, ':resumen'=>$summary, ':error'=>$error, ':cantidad'=>$found,
                ':fecha_fin'=>in_array($state, ['completada','fallida','cancelada'], true) ? date('Y-m-d H:i:s') : null,
                ':id'=>$executionId,
            ]);
        } catch (Throwable $e) {
            error_log('[NiarSales execution update] '.$e->getMessage());
        }
    }

    private function officeEvent(?int $executionId, string $type, string $state, string $message, array $detail=[], string $agentSlug='investigador'): void
    {
        try {
            $st = $this->pdo->prepare(
                "INSERT INTO eventos_agente (agente_slug, ejecucion_id, tipo, estado, mensaje, detalle_json) VALUES (:agent, :execution, :type, :state, :message, :detail)"
            );
            $st->execute([
                ':agent'=>$agentSlug, ':execution'=>$executionId, ':type'=>$type, ':state'=>$state, ':message'=>$message,
                ':detail'=>$detail ? json_encode($detail, JSON_UNESCAPED_UNICODE) : null,
            ]);
        } catch (Throwable $e) {
            // La prospección no debe fallar si la tabla de eventos todavía no fue migrada.
            error_log('[NiarSales office event] '.$e->getMessage());
        }
    }

    private function googleSearch(string $query, int $limit): array
    {
        $key = (string)($this->cfg['google_places_api_key'] ?? '');
        if ($key === '' || str_starts_with($key, 'PEGAR_')) throw new RuntimeException('Falta configurar Google Places API en api/config/agent.php.');
        if (!function_exists('curl_init')) throw new RuntimeException('La extensión cURL de PHP no está habilitada en el hosting.');

        $url = 'https://places.googleapis.com/v1/places:searchText';
        $payload = json_encode(['textQuery'=>$query, 'pageSize'=>min(20,$limit), 'languageCode'=>'es', 'regionCode'=>'AR']);
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_POST=>true, CURLOPT_RETURNTRANSFER=>true, CURLOPT_POSTFIELDS=>$payload,
            CURLOPT_HTTPHEADER=>[
                'Content-Type: application/json',
                'X-Goog-Api-Key: '.$key,
                'X-Goog-FieldMask: places.id,places.displayName,places.formattedAddress,places.nationalPhoneNumber,places.internationalPhoneNumber,places.websiteUri,places.googleMapsUri,places.primaryType,places.types,places.rating,places.userRatingCount'
            ],
            CURLOPT_TIMEOUT=>30
        ]);
        $body = curl_exec($ch); $status=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE); $err=curl_error($ch); curl_close($ch);
        if ($body === false) throw new RuntimeException('No se pudo consultar Google Places: '.$err);
        $json = json_decode((string)$body,true);
        if ($status < 200 || $status >= 300) {
            $msg = $json['error']['message'] ?? ('HTTP '.$status);
            throw new RuntimeException('Google Places rechazó la búsqueda: '.$msg);
        }
        return array_slice($json['places'] ?? [],0,$limit);
    }

    /**
     * Normaliza teléfonos argentinos para almacenarlos sin separadores.
     * Google internationalPhoneNumber es la fuente preferida porque permite
     * distinguir +54 9 (móvil) de +54 (línea fija). Nunca se inventa el 9.
     */
    private function phoneData(array $place): array
    {
        $national = trim((string)($place['nationalPhoneNumber'] ?? ''));
        $international = trim((string)($place['internationalPhoneNumber'] ?? ''));
        $original = $national !== '' ? $national : ($international !== '' ? $international : null);
        $source = $international !== '' ? $international : $national;
        $digits = preg_replace('/\\D+/', '', $source) ?? '';
        if (str_starts_with($digits, '00')) $digits = substr($digits, 2);

        $type = 'desconocido';
        if ($digits !== '' && str_starts_with($digits, '549')) {
            $type = 'celular';
        } elseif ($international !== '' && str_starts_with($digits, '54')) {
            // +54 sin el 9 suele representar fijo, pero no lo damos por
            // confirmado: Google puede entregar formatos inconsistentes.
            // La ficha permite que el usuario confirme manualmente el tipo.
            $type = 'desconocido';
        } elseif ($international === '' && str_starts_with($digits, '54')) {
            $type = 'desconocido';
        } elseif ($digits !== '' && str_starts_with($digits, '0')) {
            // Formato nacional argentino: quitamos el 0 troncal y agregamos 54.
            // Sin formato internacional no podemos asegurar el tipo de línea.
            $nationalDigits = substr($digits, 1);
            $mobile = $this->mobileFromNationalArgentina($nationalDigits);
            if ($mobile !== null) {
                $digits = $mobile;
                $type = 'celular';
            } else {
                $digits = '54' . $nationalDigits;
            }
        } elseif ($digits !== '' && strlen($digits) >= 8 && strlen($digits) <= 11) {
            $mobile = $this->mobileFromNationalArgentina($digits);
            if ($mobile !== null) {
                $digits = $mobile;
                $type = 'celular';
            } else {
                $digits = '54' . $digits;
            }
        }

        // Solo aceptamos un número internacional de longitud plausible.
        if ($digits === '' || strlen($digits) < 8 || strlen($digits) > 15) $digits = '';
        if ($type === 'celular' && !str_starts_with($digits, '549')) $type = 'desconocido';

        return [
            'telefono' => $digits !== '' ? $digits : null,
            'telefono_original' => $original,
            'telefono_tipo' => $type,
        ];
    }

    /** Convierte el formato nacional argentino 0 + área + 15 + abonado. */
    private function mobileFromNationalArgentina(string $digits): ?string
    {
        $areaCodes = [
            '11','220','221','223','230','236','237','249','260','261','263','264','266',
            '280','290','291','292','293','294','297','298','299','336','341','342','343',
            '345','346','348','349','351','353','354','356','358','362','364','370','371',
            '372','373','375','376','379','380','381','382','383','385','386','387','388'
        ];
        usort($areaCodes, static fn($a,$b) => strlen($b) <=> strlen($a));
        foreach ($areaCodes as $area) {
            $prefix = $area . '15';
            if (str_starts_with($digits, $prefix)) {
                $subscriber = substr($digits, strlen($prefix));
                if (strlen($subscriber) >= 6 && strlen($subscriber) <= 8) return '549' . $area . $subscriber;
            }
        }
        return null;
    }

    /** Obtiene texto público de la web oficial del comercio, si existe. */
    private function researchWebsite(?string $url): array
    {
        $url = trim((string)$url);
        if ($url === '' || !filter_var($url, FILTER_VALIDATE_URL)) {
            return ['status' => 'sin_sitio_web', 'url' => null, 'text' => ''];
        }
        $scheme = strtolower((string)parse_url($url, PHP_URL_SCHEME));
        if (!in_array($scheme, ['http', 'https'], true)) {
            return ['status' => 'url_no_admitida', 'url' => $url, 'text' => ''];
        }
        if (!function_exists('curl_init')) {
            return ['status' => 'curl_no_disponible', 'url' => $url, 'text' => ''];
        }

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS => 3,
            CURLOPT_CONNECTTIMEOUT => 8,
            CURLOPT_TIMEOUT => 12,
            CURLOPT_USERAGENT => 'NiarSalesResearch/1.0 (+public business website review)',
            CURLOPT_HTTPHEADER => ['Accept: text/html,application/xhtml+xml'],
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
        ]);
        $html = curl_exec($ch);
        $status = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $type = strtolower((string)curl_getinfo($ch, CURLINFO_CONTENT_TYPE));
        $error = curl_error($ch);
        curl_close($ch);

        if (!is_string($html) || $status < 200 || $status >= 400 || (strpos($type, 'text/html') === false && strpos($type, 'application/xhtml') === false)) {
            return ['status' => 'no_accesible', 'url' => $url, 'http_status' => $status, 'error' => $error ?: null, 'text' => ''];
        }

        // Limitar el material enviado al modelo: evita páginas enormes y scripts.
        $html = substr($html, 0, 700000);
        $html = preg_replace('~<(script|style|noscript|svg|iframe)[^>]*>.*?</\1>~is', ' ', $html) ?? $html;
        $text = strip_tags($html);
        $text = html_entity_decode($text, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $text = preg_replace('/\s+/u', ' ', $text) ?? $text;
        $text = trim($text);
        $text = mb_substr($text, 0, 9000, 'UTF-8');

        return ['status' => $text !== '' ? 'consultado' : 'sin_texto_util', 'url' => $url, 'http_status' => $status, 'text' => $text];
    }

    private function analyze(array $place, string $rubro, string $localidad): array
    {
        $key=(string)($this->cfg['openai_api_key'] ?? '');
        if ($key === '' || str_starts_with($key,'PEGAR_')) throw new RuntimeException('Falta configurar OpenAI API en api/config/agent.php.');
        if (!function_exists('curl_init')) throw new RuntimeException('La extensión cURL de PHP no está habilitada en el hosting.');
        $phoneData = $this->phoneData($place);
        $business = [
            'nombre'=>$place['displayName']['text'] ?? '', 'direccion'=>$place['formattedAddress'] ?? '',
            'telefono'=>$phoneData['telefono'], 'telefono_original'=>$phoneData['telefono_original'],
            'telefono_tipo'=>$phoneData['telefono_tipo'], 'web'=>$place['websiteUri'] ?? null,
            'google_maps'=>$place['googleMapsUri'] ?? null, 'tipo_google'=>$place['primaryType'] ?? null,
            'rating'=>$place['rating'] ?? null, 'cantidad_resenas'=>$place['userRatingCount'] ?? null,
        ];
        $websiteResearch = $this->researchWebsite($business['web']);
        $business['investigacion_web'] = [
            'estado' => $websiteResearch['status'],
            'url' => $websiteResearch['url'],
            'http_status' => $websiteResearch['http_status'] ?? null,
            'texto_publico' => $websiteResearch['text'],
        ];
        $system = 'Sos un investigador comercial B2B senior de NiarSales. Tu objetivo es descubrir oportunidades concretas para MesAPP, no limitarte a describir el comercio. Analizá la ficha de Google Places y, cuando exista, el texto público extraído del sitio oficial. No inventes datos, no supongas que una función no existe porque no aparece en el texto y no afirmes haber revisado redes sociales. Separá HECHOS observados de HIPÓTESIS comerciales. Priorizá señales accionables: menú/carta online, pedidos digitales, canal de WhatsApp, facilidad de compra, presencia web, información de contacto y fricciones visibles. Si no hay evidencia suficiente, indicá qué falta y bajá la confianza. Respondé exclusivamente JSON válido con las claves: score (entero 0-100), prioridad (alta|media|baja), potencial (texto breve y específico), oportunidad_detectada (texto concreto o "No determinada"), evidencia (array de objetos con hallazgo, fuente y tipo=hecho|indicio), ajuste_mesapp (texto concreto), accion_recomendada (texto breve), confianza (alta|media|baja), motivos (array de 2 a 4 strings), datos_faltantes (array), mensaje_sugerido (texto breve, personalizado, cordial y no engañoso). No afirmes que el comercio carece de menú digital o pedidos online salvo evidencia explícita. Si no encontrás esa información tras revisar la fuente disponible, usá exactamente una formulación prudente como "No encontramos un menú digital visible en la información revisada" o "No pudimos verificar si ofrece pedidos online"; nunca lo presentes como una carencia confirmada.';
        $user = 'Producto: '.($this->cfg['product_name'] ?? 'MesAPP').'. Descripción: '.($this->cfg['product_description'] ?? '')."\nRubro buscado: {$rubro}\nLocalidad buscada: {$localidad}\nFicha de Google Places y revisión pública del sitio oficial (si estuvo disponible):\n".json_encode($business,JSON_UNESCAPED_UNICODE);
        $model=(string)($this->cfg['openai_model'] ?? 'gpt-4.1-mini');
        $maxOutput=700;
        $payload = ['model'=>$model,'messages'=>[['role'=>'system','content'=>$system],['role'=>'user','content'=>$user]],'response_format'=>['type'=>'json_object'],'temperature'=>0.2,'max_tokens'=>$maxOutput];
        // Reserva conservadora antes de llamar a OpenAI. Si no hay saldo, no se realiza la llamada.
        $estimatedInput=(int)ceil((strlen($system)+strlen($user))/3*1.25);
        $usageId=$this->budget->reserve($model,$estimatedInput,$maxOutput);
        try {
            $ch=curl_init('https://api.openai.com/v1/chat/completions');
            curl_setopt_array($ch,[CURLOPT_POST=>true,CURLOPT_RETURNTRANSFER=>true,CURLOPT_POSTFIELDS=>json_encode($payload),CURLOPT_HTTPHEADER=>['Content-Type: application/json','Authorization: Bearer '.$key],CURLOPT_TIMEOUT=>40]);
            $body=curl_exec($ch);$status=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);$err=curl_error($ch);curl_close($ch);
            if($body===false) throw new RuntimeException('No se pudo consultar OpenAI: '.$err);
            $json=json_decode((string)$body,true);
            if($status<200||$status>=300) throw new RuntimeException('OpenAI rechazó el análisis: '.($json['error']['message']??('HTTP '.$status)));
            $content=$json['choices'][0]['message']['content']??'{}';
            $analysis=json_decode((string)$content,true);
            if(!is_array($analysis)) throw new RuntimeException('La respuesta de OpenAI no tuvo el formato esperado.');
            $inputTokens=(int)($json['usage']['prompt_tokens']??0);
            $outputTokens=(int)($json['usage']['completion_tokens']??0);
            $actualModel=(string)($json['model']??$model);
            $cost=$this->budget->settle($usageId,$actualModel,$inputTokens,$outputTokens);
            $analysis['_usage']=['input_tokens'=>$inputTokens,'output_tokens'=>$outputTokens,'model'=>$actualModel,'cost_usd'=>$cost];
            return [$business,$analysis];
        } catch (Throwable $e) {
            $this->budget->release($usageId,$e->getMessage());
            throw $e;
        }
    }

    private function findDuplicate(array $place): ?int
    {
        $idCol=$this->col(['id','ID'],true);
        $phoneCol=$this->col(['telefono','phone']);
        $webCol=$this->col(['sitio_web','web','website']);
        $nameCol=$this->col(['nombre','nombre_comercial','comercio','empresa'],true);
        $name=trim((string)($place['displayName']['text']??''));
        $phone=$this->phoneData($place)['telefono'] ?? ''; 
        $web=trim((string)($place['websiteUri']??''));
        if($phone!==''&&$phoneCol){$s=$this->pdo->prepare("SELECT `{$idCol}` FROM prospectos WHERE `{$phoneCol}`=:v LIMIT 1");$s->execute(['v'=>$phone]);$x=$s->fetchColumn();if($x)return (int)$x;}
        if($web!==''&&$webCol){$s=$this->pdo->prepare("SELECT `{$idCol}` FROM prospectos WHERE `{$webCol}`=:v LIMIT 1");$s->execute(['v'=>$web]);$x=$s->fetchColumn();if($x)return (int)$x;}
        if($name!==''){$s=$this->pdo->prepare("SELECT `{$idCol}` FROM prospectos WHERE `{$nameCol}`=:v LIMIT 1");$s->execute(['v'=>$name]);$x=$s->fetchColumn();if($x)return (int)$x;}
        return null;
    }

    /** Completa el Google Place ID de un prospecto existente cuando el agente lo reconoce como duplicado. */
    private function backfillGooglePlaceId(int $prospectId, array $place): void
    {
        $placeId = trim((string)($place['id'] ?? ''));
        if ($placeId === '') return;
        $idColumn = $this->col(['id', 'ID'], true);
        $placeColumn = $this->col(['google_place_id', 'place_id']);
        if (!$placeColumn) {
            error_log('[NiarSales Google Place ID] Falta la columna google_place_id/place_id en prospectos. Ejecutar la migración SQL incluida.');
            return;
        }
        $stmt = $this->pdo->prepare("UPDATE prospectos SET `{$placeColumn}` = :place_id WHERE `{$idColumn}` = :id AND (`{$placeColumn}` IS NULL OR `{$placeColumn}` = '')");
        $stmt->execute(['place_id' => $placeId, 'id' => $prospectId]);
    }

    private function rubroId(string $rubro): ?int
    {
        try {
            $q=$this->pdo->query('SELECT * FROM rubros');
            foreach($q->fetchAll(PDO::FETCH_ASSOC) as $row){
                $name=(string)($row['nombre']??$row['Nombre']??'');
                if($name!==''&&(mb_strtolower($name)===mb_strtolower($rubro)||str_contains(mb_strtolower($rubro),mb_strtolower($name)))) return (int)($row['id']??$row['ID']??0) ?: null;
            }
        } catch(Throwable $e) {}
        return null;
    }

    private function sourceId(): ?int
    {
        try {
            $q=$this->pdo->query('SELECT * FROM fuentes_prospectos');
            foreach($q->fetchAll(PDO::FETCH_ASSOC) as $row){
                $name=mb_strtolower((string)($row['nombre']??$row['Nombre']??''));
                if(str_contains($name,'api')||str_contains($name,'búsqueda')||str_contains($name,'busqueda')) return (int)($row['id']??$row['ID']??0) ?: null;
            }
        } catch(Throwable $e) {}
        return null;
    }

    private function saveProspect(array $place, array $business, array $analysis, int $userId): ?int
    {
        $name=trim((string)($business['nombre']??''));
        if($name==='') return null;
        $values=[];
        $map=[
            'nombre'=>['nombre','nombre_comercial','comercio','empresa'],
            'telefono'=>['telefono','phone'],
            'telefono_original'=>['telefono_original'],
            'telefono_tipo'=>['telefono_tipo'],
            'email'=>['email','correo'],
            'sitio_web'=>['sitio_web','web','website'],
            'direccion'=>['direccion','domicilio'],
            'localidad'=>['localidad','ciudad'],
            'pais'=>['pais'],
            'estado'=>['estado'],
            'prioridad'=>['prioridad'],
            'score'=>['score','puntaje'],
            'mensaje_sugerido_ia'=>['mensaje_sugerido_ia'],
            'notas'=>['notas','observaciones'],
            'rubro_id'=>['rubro_id','id_rubro'],
            'fuente_id'=>['fuente_id','fuente_prospecto_id','id_fuente'],
            'creado_por'=>['creado_por','usuario_creador_id'],
            'created_at'=>['created_at','fecha_creacion','fecha_alta'],
            'google_maps_url'=>['google_maps_url','url_google_maps'],
            'google_place_id'=>['google_place_id','place_id'],
        ];
        $put=function(string $key,$value) use (&$values,$map):void{
            foreach($map[$key]??[$key] as $candidate) if(in_array($candidate,$this->prospectColumns,true)){ $values[$candidate]=$value;break;}
        };
        $put('nombre',$name);$put('telefono',$business['telefono']);$put('telefono_original',$business['telefono_original']??null);$put('telefono_tipo',$business['telefono_tipo']??'desconocido');$put('email',null);
        $put('sitio_web',$business['web']);$put('direccion',$business['direccion']);
        $put('localidad',$this->currentLocality);$put('pais','Argentina');$put('estado','nuevo');
        $put('prioridad',$analysis['prioridad']??'media');$put('score',max(0,min(100,(int)($analysis['score']??0))));
        $put('mensaje_sugerido_ia',trim((string)($analysis['mensaje_sugerido']??'')));
        $put('notas',"Investigación comercial de NiarSales\nPotencial: ".($analysis['potencial']??'')."\nOportunidad detectada: ".($analysis['oportunidad_detectada']??'No determinada')."\nAjuste MesAPP: ".($analysis['ajuste_mesapp']??'')."\nAcción recomendada: ".($analysis['accion_recomendada']??'')."\nConfianza: ".($analysis['confianza']??'no indicada')."\nEvidencia: ".json_encode($analysis['evidencia']??[],JSON_UNESCAPED_UNICODE)."\nMotivos: ".implode('; ',(array)($analysis['motivos']??[]))."\nDatos faltantes: ".implode('; ',(array)($analysis['datos_faltantes']??[]))."\nMensaje sugerido: ".($analysis['mensaje_sugerido']??''));
        $put('rubro_id',$this->rubroId((string)($this->currentRubro??'')));$put('fuente_id',$this->sourceId());
        $put('creado_por',$userId);$put('created_at',date('Y-m-d H:i:s'));
        $put('google_maps_url',$business['google_maps']);
        $placeIdColumn = $this->col(['google_place_id', 'place_id']);
        if (!$placeIdColumn) {
            throw new RuntimeException('Falta la columna google_place_id en la tabla prospectos. Ejecutá la migración MIGRACION_google_place_id.sql incluida en el paquete.');
        }
        $values[$placeIdColumn] = trim((string)($place['id'] ?? '')) ?: null;
        if(!$values) throw new RuntimeException('No se encontraron columnas compatibles para guardar el prospecto.');
        $columns=array_keys($values);$sql='INSERT INTO prospectos (`'.implode('`,`',$columns).'`) VALUES (:'.implode(',:',$columns).')';
        $st=$this->pdo->prepare($sql);foreach($values as $k=>$v)$st->bindValue(':'.$k,$v);$st->execute();
        return (int)$this->pdo->lastInsertId();
    }

    private ?string $currentRubro = null;
    private ?string $currentLocality = null;

    private function logResult(?int $executionId, ?int $prospectId, string $title, array $business, array $analysis): void
    {
        try {
            $this->insertDynamic('resultados_agente',[
                'ejecucion_id'=>['ejecucion_id','id_ejecucion'],
                'prospecto_id'=>['prospecto_id','id_prospecto'],
                'tipo'=>['tipo','tipo_resultado'],
                'titulo'=>['titulo','title'],
                'contenido'=>['contenido','content','resumen'],
                'datos'=>['datos_json','datos','resultado_json'],
                'created_at'=>['created_at','fecha_creacion'],
            ],[
                'ejecucion_id'=>$executionId,'prospecto_id'=>$prospectId,'tipo'=>'prospecto_encontrado',
                'titulo'=>$business['nombre']??'Comercio',
                'contenido'=>(string)($analysis['potencial']??''),
                'datos'=>json_encode(['business'=>$business,'analysis'=>$analysis],JSON_UNESCAPED_UNICODE),
                'created_at'=>date('Y-m-d H:i:s')
            ]);
        } catch(Throwable $e){ error_log('[NiarSales result log] '.$e->getMessage()); }
    }

    public function run(bool $coordinatedByNora = false): never
    {
        $userId=$this->requireUser();$this->requireCsrf();
        // Evita que dobles clics o pestañas simultáneas creen investigaciones duplicadas.
        $activeCheck = $this->pdo->query("SELECT id FROM ejecuciones_agente WHERE estado = 'ejecutando' ORDER BY id DESC LIMIT 1");
        $activeId = $activeCheck ? $activeCheck->fetchColumn() : false;
        if ($activeId) {
            Response::json(['success'=>false,'message'=>'Ya hay una investigación en curso (ejecución #'.(int)$activeId.'). Esperá a que termine antes de asignar otra.'], 409);
        }
        // Liberamos el lock de sesión para que la oficina pueda consultar el progreso mientras corre la investigación.
        if (session_status() === PHP_SESSION_ACTIVE) session_write_close();
        $data=$this->input();
        $rubro=trim((string)($data['rubro']??''));
        $localidad=trim((string)($data['localidad']??''));
        $limit=max(1,min((int)($this->cfg['max_results_per_run']??10),(int)($data['cantidad']??5)));
        if($rubro===''||$localidad==='') Response::json(['success'=>false,'message'=>'Indicá el rubro y la localidad que querés investigar.'],422);
        $this->currentRubro=$rubro;
        $this->currentLocality=$localidad;
        $objective="Buscar {$rubro} en {$localidad}, Argentina";
        $executionId=$this->saveExecution('en_proceso',$objective,['rubro'=>$rubro,'localidad'=>$localidad,'cantidad'=>$limit,'coordinated_by_nora'=>$coordinatedByNora]);
        if ($coordinatedByNora) {
            $this->officeEvent($executionId, 'mision_asignada', 'planning', 'Recibí el objetivo y asigné la investigación comercial a Ivo.', ['delegado_a'=>'investigador','objetivo'=>$objective], 'coordinador');
        }
        $this->officeEvent($executionId, 'tarea_iniciada', 'working', 'Recibí una nueva investigación: '.$objective, ['rubro'=>$rubro,'localidad'=>$localidad,'cantidad'=>$limit]);
        try{
            $places=$this->googleSearch($objective,$limit);
            $this->officeEvent($executionId, 'busqueda_completada', 'working', 'Google Places devolvió '.count($places).' comercios para revisar.', ['encontrados'=>count($places)]);
            $saved=[];$duplicates=0;$errors=[];
            foreach($places as $place){
                try{
                    $duplicate=$this->findDuplicate($place);
                    if($duplicate){
                        // No crea otro prospecto, pero aprovecha la ficha recién encontrada para completar su Place ID.
                        $this->backfillGooglePlaceId($duplicate, $place);
                        $duplicates++;
                        continue;
                    }
                    [$business,$analysis]=$this->analyze($place,$rubro,$localidad);
                    $prospectId=$this->saveProspect($place,$business,$analysis,$userId);
                    $this->logResult($executionId,$prospectId,$business['nombre'],$business,$analysis);
                    $this->officeEvent($executionId, 'prospecto_analizado', 'working', 'Analicé '.$business['nombre'].' y lo registré como prospecto.', ['prospecto_id'=>$prospectId,'score'=>(int)($analysis['score']??0)]);
                    $saved[]=['id'=>$prospectId,'nombre'=>$business['nombre'],'direccion'=>$business['direccion'],'telefono'=>$business['telefono'],'telefono_original'=>$business['telefono_original']??null,'telefono_tipo'=>$business['telefono_tipo']??'desconocido','web'=>$business['web'],'google_maps'=>$business['google_maps'],'score'=>(int)($analysis['score']??0),'prioridad'=>$analysis['prioridad']??'media','potencial'=>$analysis['potencial']??'','oportunidad_detectada'=>$analysis['oportunidad_detectada']??'No determinada','ajuste_mesapp'=>$analysis['ajuste_mesapp']??'','accion_recomendada'=>$analysis['accion_recomendada']??'','confianza'=>$analysis['confianza']??'no indicada','evidencia'=>$analysis['evidencia']??[],'motivos'=>$analysis['motivos']??[],'mensaje_sugerido'=>$analysis['mensaje_sugerido']??''];
                }catch(BudgetExceededException $e){$errors[]=$e->getMessage();error_log('[NiarSales agent budget] '.$e->getMessage());break;}catch(Throwable $e){$errors[]=$e->getMessage();error_log('[NiarSales agent item] '.$e->getMessage());}
            }
            $summary=count($saved).' prospectos nuevos guardados; '.$duplicates.' duplicados omitidos.';
            $this->updateExecution($executionId, 'completada', $summary, $errors?implode(' | ',array_slice($errors,0,5)):null, count($places), count($saved));
            $this->officeEvent($executionId, 'tarea_completada', 'success', $summary, ['encontrados'=>count($places),'guardados'=>count($saved),'duplicados'=>$duplicates]);
            if ($coordinatedByNora) {
                $this->officeEvent($executionId, 'resultado_recibido', 'success', 'Recibí el informe de Ivo: '.$summary, ['agente'=>'coordinadora','resumen'=>$summary], 'coordinador');
            }
            Response::json(['success'=>true,'message'=>$summary,'execution_id'=>$executionId,'found'=>count($places),'saved'=>count($saved),'duplicates'=>$duplicates,'errors'=>$errors,'budget'=>$this->budget->status(),'data'=>$saved]);
        }catch(Throwable $e){
            $this->updateExecution($executionId, 'error', null, $e->getMessage());
            $this->officeEvent($executionId, 'tarea_fallida', 'error', 'La investigación falló: '.$e->getMessage());
            if ($coordinatedByNora) {
                $this->officeEvent($executionId, 'delegacion_fallida', 'error', 'Recibí el aviso de que la tarea de Ivo no pudo completarse.', [], 'coordinador');
            }
            error_log('[NiarSales agent run] '.$e->getMessage());
            Response::json(['success'=>false,'message'=>$e->getMessage()],500);
        }
    }
}
