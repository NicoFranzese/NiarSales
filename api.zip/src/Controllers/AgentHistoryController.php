<?php
declare(strict_types=1);

namespace NiarSales\Controllers;

use NiarSales\Core\Database;
use NiarSales\Core\Response;
use PDO;

final class AgentHistoryController
{
    private PDO $pdo;
    public function __construct(array $dbConfig) { $this->pdo = Database::connection($dbConfig); }

    private function authorize(): void {
        if (empty($_SESSION['user']['id'])) Response::json(['success'=>false,'message'=>'La sesión expiró. Iniciá sesión nuevamente.'],401);
    }
    private function jsonValue(?string $value): array {
        if (!$value) return [];
        $decoded=json_decode($value,true);
        return is_array($decoded)?$decoded:[];
    }

    public function agentHistory(string $slug): never {
        $this->authorize();
        $allowed=['coordinador','investigador','analista','ventas','seguimiento'];
        if(!in_array($slug,$allowed,true)) Response::json(['success'=>false,'message'=>'Agente no válido.'],422);
        $agentStmt=$this->pdo->prepare('SELECT slug,nombre,rol,sala,descripcion,avatar,habilitado FROM agentes_niarsales WHERE slug=:slug LIMIT 1');
        $agentStmt->execute(['slug'=>$slug]);
        $agent=$agentStmt->fetch(PDO::FETCH_ASSOC);
        if(!$agent) Response::json(['success'=>false,'message'=>'No se encontró el agente solicitado.'],404);

        $sql="SELECT e.id,e.tipo,e.estado,e.objetivo,e.resultado_resumen,e.error_detalle,
                     e.cantidad_prospectos,e.fecha_inicio,e.fecha_fin,e.created_at,
                     COUNT(DISTINCT r.id) AS cantidad_resultados,COUNT(DISTINCT ev.id) AS cantidad_eventos
              FROM eventos_agente ev
              INNER JOIN ejecuciones_agente e ON e.id=ev.ejecucion_id
              LEFT JOIN resultados_agente r ON r.ejecucion_id=e.id
              WHERE ev.agente_slug=:slug
              GROUP BY e.id,e.tipo,e.estado,e.objetivo,e.resultado_resumen,e.error_detalle,
                       e.cantidad_prospectos,e.fecha_inicio,e.fecha_fin,e.created_at
              ORDER BY COALESCE(e.fecha_inicio,e.created_at) DESC LIMIT 100";
        $stmt=$this->pdo->prepare($sql);$stmt->execute(['slug'=>$slug]);$tasks=$stmt->fetchAll(PDO::FETCH_ASSOC);
        foreach($tasks as &$task){$task['id']=(int)$task['id'];$task['cantidad_prospectos']=(int)$task['cantidad_prospectos'];$task['cantidad_resultados']=(int)$task['cantidad_resultados'];$task['cantidad_eventos']=(int)$task['cantidad_eventos'];}
        unset($task);
        Response::json(['success'=>true,'data'=>['agent'=>$agent,'tasks'=>$tasks]]);
    }

    public function executionDetail(int $executionId): never {
        $this->authorize();
        $stmt=$this->pdo->prepare('SELECT id,tipo,estado,objetivo,parametros_json,resultado_resumen,error_detalle,cantidad_prospectos,fecha_inicio,fecha_fin,created_at FROM ejecuciones_agente WHERE id=:id LIMIT 1');
        $stmt->execute(['id'=>$executionId]);$execution=$stmt->fetch(PDO::FETCH_ASSOC);
        if(!$execution) Response::json(['success'=>false,'message'=>'No se encontró la ejecución solicitada.'],404);

        $eventsStmt=$this->pdo->prepare('SELECT id,agente_slug,tipo,estado,mensaje,detalle_json,created_at FROM eventos_agente WHERE ejecucion_id=:id ORDER BY id ASC');
        $eventsStmt->execute(['id'=>$executionId]);$events=$eventsStmt->fetchAll(PDO::FETCH_ASSOC);
        foreach($events as &$event){$event['id']=(int)$event['id'];$event['detalle']=$this->jsonValue($event['detalle_json']??null);unset($event['detalle_json']);}
        unset($event);

        $resultStmt=$this->pdo->prepare("SELECT r.id,r.prospecto_id,r.tipo,r.titulo,r.contenido,r.datos_json,r.created_at,
                                                p.nombre_comercial,p.razon_social,p.sitio_web,p.instagram_url,p.facebook_url,p.telefono,p.email,p.direccion,p.localidad,p.provincia,p.pais,
                                                p.estado AS estado_prospecto,p.prioridad AS prioridad_ivo,p.puntuacion AS puntuacion_ivo,
                                                p.ada_puntuacion,p.ada_prioridad,p.ada_resumen,p.ada_recomendacion,p.ada_analisis_json,p.ada_analizado_at,
                                                rb.nombre AS rubro
                                         FROM resultados_agente r
                                         LEFT JOIN prospectos p ON p.id=r.prospecto_id
                                         LEFT JOIN rubros rb ON rb.id=p.rubro_id
                                         WHERE r.ejecucion_id=:id ORDER BY r.id ASC");
        $resultStmt->execute(['id'=>$executionId]);$results=$resultStmt->fetchAll(PDO::FETCH_ASSOC);
        foreach($results as &$result){
            $result['id']=(int)$result['id'];$result['prospecto_id']=$result['prospecto_id']!==null?(int)$result['prospecto_id']:null;
            $result['datos']=$this->jsonValue($result['datos_json']??null);unset($result['datos_json']);
            $result['analisis_ada']=$this->jsonValue($result['ada_analisis_json']??null);
        }
        unset($result);
        $execution['id']=(int)$execution['id'];$execution['cantidad_prospectos']=(int)$execution['cantidad_prospectos'];
        $execution['parametros']=$this->jsonValue($execution['parametros_json']??null);unset($execution['parametros_json']);
        Response::json(['success'=>true,'data'=>['execution'=>$execution,'events'=>$events,'results'=>$results]]);
    }
}
