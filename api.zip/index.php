<?php
declare(strict_types=1);
use NiarSales\Core\Response;

header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: strict-origin-when-cross-origin');
header('Cache-Control: no-store, max-age=0');

require_once __DIR__.'/src/Core/Response.php';
require_once __DIR__.'/src/Core/Database.php';
require_once __DIR__.'/src/Core/AuthGuard.php';
require_once __DIR__.'/src/Core/BudgetService.php';
require_once __DIR__.'/src/Controllers/HealthController.php';
require_once __DIR__.'/src/Controllers/AuthController.php';
require_once __DIR__.'/src/Controllers/ProspectController.php';
require_once __DIR__.'/src/Controllers/AgentController.php';
require_once __DIR__.'/src/Controllers/BudgetController.php';
require_once __DIR__.'/src/Controllers/ActivityController.php';
require_once __DIR__.'/src/Controllers/ClientController.php';
require_once __DIR__.'/src/Controllers/OfficeController.php';
require_once __DIR__.'/src/Controllers/AdaController.php';
require_once __DIR__.'/src/Controllers/AgentHistoryController.php';
require_once __DIR__.'/src/Controllers/ProspectAgentController.php';

$appConfig=require __DIR__.'/config/app.php';
$dbConfig=require __DIR__.'/config/database.php';
$agentConfigFile=__DIR__.'/config/agent.php';
$agentConfig=is_file($agentConfigFile)?require $agentConfigFile:[];

$origin=$_SERVER['HTTP_ORIGIN']??'';
$allowed=$appConfig['allowed_origins']??[];
if($origin!==''&&in_array($origin,$allowed,true)){
 header('Access-Control-Allow-Origin: '.$origin);header('Vary: Origin');header('Access-Control-Allow-Credentials: true');
 header('Access-Control-Allow-Methods: GET, POST, PUT, OPTIONS');
 header('Access-Control-Allow-Headers: Content-Type, X-CSRF-Token, X-Requested-With');header('Access-Control-Max-Age: 86400');
}
$method=strtoupper($_SERVER['REQUEST_METHOD']??'GET');
if($method==='OPTIONS'){http_response_code(204);exit;}
if($origin!==''&&!in_array($origin,$allowed,true)) Response::json(['success'=>false,'message'=>'Origen no autorizado.'],403);

ini_set('session.use_strict_mode','1');ini_set('session.use_only_cookies','1');ini_set('session.cookie_httponly','1');ini_set('session.cookie_secure','1');ini_set('session.cookie_samesite','Lax');
session_name('NIARSALESSESSID');
session_set_cookie_params([
    'lifetime' => 0,
    'path' => '/',
    'secure' => true,
    'httponly' => true,
    'samesite' => 'Lax'
]);
if(session_status()!==PHP_SESSION_ACTIVE)session_start();

$uri=$_SERVER['REQUEST_URI']??'/';$path=parse_url($uri,PHP_URL_PATH);$path=is_string($path)?$path:'/';
$dir=rtrim(str_replace('\\','/',dirname($_SERVER['SCRIPT_NAME']??'/api/index.php')),'/');
if($dir!==''&&str_starts_with($path,$dir))$path=substr($path,strlen($dir));
$path='/'.trim($path,'/');
try{$router=require __DIR__.'/routes/api.php';$router($method,$path,$dbConfig,$agentConfig);}
catch(Throwable $e){error_log('[NiarSales API] '.$e->getMessage());Response::json(['success'=>false,'message'=>'Ocurrió un error interno en la API.'],500);}
