<?php
declare(strict_types=1);
use NiarSales\Controllers\AuthController;
use NiarSales\Controllers\HealthController;
use NiarSales\Controllers\ProspectController;
use NiarSales\Controllers\AgentController;
use NiarSales\Controllers\BudgetController;
use NiarSales\Controllers\ActivityController;
use NiarSales\Controllers\ClientController;
use NiarSales\Controllers\OfficeController;
use NiarSales\Controllers\AdaController;
use NiarSales\Controllers\AgentHistoryController;
use NiarSales\Controllers\ProspectAgentController;
use NiarSales\Core\Response;

return static function(string $method,string $path,array $dbConfig,array $agentConfig=[]):void{
 $auth=new AuthController();
 if($path==='/health'||$path==='/'){if($method!=='GET')Response::json(['success'=>false,'message'=>'Método no permitido.'],405);(new HealthController())->index($dbConfig);}
 if($path==='/auth/login'){if($method!=='POST')Response::json(['success'=>false,'message'=>'Método no permitido.'],405);$auth->login($dbConfig);}
 if($path==='/auth/me'){if($method!=='GET')Response::json(['success'=>false,'message'=>'Método no permitido.'],405);$auth->me();}
 if($path==='/auth/logout'){if($method!=='POST')Response::json(['success'=>false,'message'=>'Método no permitido.'],405);$auth->logout();}
 if($path==='/budget/status'&&$method==='GET')(new BudgetController($dbConfig))->status();
 if($path==='/budget/config'&&$method==='PUT')(new BudgetController($dbConfig))->update();

 if($path==='/prospects/catalogs'&&$method==='GET')(new ProspectController($dbConfig,$agentConfig))->catalogs();
 if($path==='/prospects'&&$method==='GET')(new ProspectController($dbConfig,$agentConfig))->list();
 if($path==='/prospects'&&$method==='POST')(new ProspectController($dbConfig,$agentConfig))->save();
 if(preg_match('#^/prospects/([0-9]+)/review-summary$#',$path,$m)&&$method==='GET'){(new ProspectController($dbConfig,$agentConfig))->reviewSummary((int)$m[1]);}
 if(preg_match('#^/prospects/([0-9]+)$#',$path,$m)){
   $controller=new ProspectController($dbConfig,$agentConfig);
   if($method==='GET')$controller->detail((int)$m[1]);
   if($method==='PUT')$controller->save((int)$m[1]);
 }
 if(preg_match('#^/prospects/([0-9]+)/agent-work$#',$path,$m)&&$method==='GET')(new ProspectAgentController($dbConfig,$agentConfig))->list((int)$m[1]);
 if(preg_match('#^/prospects/([0-9]+)/agents/(leo|mia)/(draft|plan)$#',$path,$m)&&$method==='POST'){
   $agent=$m[2]==='leo'?'ventas':'seguimiento';
   (new ProspectAgentController($dbConfig,$agentConfig))->run((int)$m[1],$agent);
 }
 if(preg_match('#^/prospects/([0-9]+)/activities$#',$path,$m)){
   $controller=new ActivityController($dbConfig);
   if($method==='GET')$controller->list((int)$m[1]);
   if($method==='POST')$controller->create((int)$m[1]);
 }
 if($path==='/clients'&&$method==='GET')(new ClientController($dbConfig))->listing();
 if($path==='/clients'&&$method==='POST')(new ClientController($dbConfig))->save();
 if(preg_match('#^/clients/([0-9]+)$#',$path,$m)&&$method==='GET')(new ClientController($dbConfig))->detail((int)$m[1]);
 if(preg_match('#^/clients/([0-9]+)$#',$path,$m)&&$method==='PUT')(new ClientController($dbConfig))->save((int)$m[1]);
 if(preg_match('#^/clients/([0-9]+)/tariffs$#',$path,$m)&&$method==='POST')(new ClientController($dbConfig))->tariff((int)$m[1]);
 if(preg_match('#^/clients/([0-9]+)/tariffs/([0-9]+)$#',$path,$m)&&$method==='DELETE')(new ClientController($dbConfig))->deleteTariff((int)$m[1],(int)$m[2]);
 if(preg_match('#^/clients/([0-9]+)/charges$#',$path,$m)&&$method==='POST')(new ClientController($dbConfig))->charge((int)$m[1]);
 if(preg_match('#^/clients/([0-9]+)/charges/([0-9]+)$#',$path,$m)){ $controller=new ClientController($dbConfig); if($method==='PUT')$controller->updateCharge((int)$m[1],(int)$m[2]); if($method==='DELETE')$controller->deleteCharge((int)$m[1],(int)$m[2]); }
 if(preg_match('#^/clients/([0-9]+)/payments$#',$path,$m)&&$method==='POST')(new ClientController($dbConfig))->payment((int)$m[1]);
 if($path==='/agent/office'&&$method==='GET')(new OfficeController($dbConfig))->snapshot();
 if(preg_match('#^/agent/agents/([a-z_-]+)/history$#',$path,$m) && $method==='GET'){
   (new AgentHistoryController($dbConfig))->agentHistory($m[1]);
 }
 if(preg_match('#^/agent/executions/([0-9]+)$#',$path,$m) && $method==='GET'){
   (new AgentHistoryController($dbConfig))->executionDetail((int)$m[1]);
 }
 if($path==='/agent/ada/candidates'&&$method==='GET')(new AdaController($dbConfig,$agentConfig))->candidates();
 if($path==='/agent/ada/analyze'){
   if($method!=='POST')Response::json(['success'=>false,'message'=>'Método no permitido.'],405);
   (new AdaController($dbConfig,$agentConfig))->run();
 }
 if($path==='/agent/run' || $path==='/agent/coordinate'){
   if($method!=='POST')Response::json(['success'=>false,'message'=>'Método no permitido.'],405);
   (new AgentController($dbConfig,$agentConfig))->run($path==='/agent/coordinate');
 }
 Response::json(['success'=>false,'message'=>'Ruta de API no encontrada.'],404);
};
